import { encode, emptyEncodeState } from './vendor/fjs/sul/module.f.mjs';
import { isHash, isRaw } from './vendor/fjs/sul/id/module.f.mjs';
import { literal3ToVec, level } from './vendor/fjs/sul/level/literal/module.f.mjs';
import { unpack } from './vendor/fjs/types/bit_vec/module.f.mjs';
import { toArray } from './vendor/fjs/types/list/module.f.mjs';
import { patriciaTrie } from './vendor/fjs/types/patricia_trie/module.f.mjs';

export const bytesToBits = bytes => [...bytes].map(x => x.toString(2).padStart(8, '0')).join('');
export const bitsToBytes = bits => {
    const out = Buffer.alloc(Math.ceil(bits.length / 8));
    for (let i = 0; i < bits.length; i++) if (bits[i] === '1') out[i >> 3] |= 1 << (7 - (i & 7));
    return out;
};
const literalBits = id => {
    if (isRaw(id)) return (id ^ (1n << 254n)).toString(2).slice(1);
    const { length, uint } = unpack(literal3ToVec(id));
    return uint.toString(2).padStart(Number(length), '0');
};

export function capture(bits) {
    const merges = new Map();
    const enc = encode((a, b, id, _symbol, storage) => {
        // Raw IDs can have several decompositions, all with identical bits.
        // Retain the first encountered derivation; every child is shorter.
        if (!merges.has(id)) merges.set(id, [a, b]);
        return storage;
    });
    let state = emptyEncodeState(null);
    for (const bit of bits) state = enc.push(BigInt(bit), state);
    return { root: enc.end(state), merges };
}

class Graph {
    nodes = []; interned = new Map();
    literal(bits) {
        const key = 'b:' + bits;
        if (this.interned.has(key)) return this.interned.get(key);
        const node = { id: this.nodes.length, length: bits.length, bits };
        this.nodes.push(node); this.interned.set(key, node); return node;
    }
    pair(left, right) {
        const length = left.length + right.length;
        const bits = length <= 253 ? flatten(left) + flatten(right) : undefined;
        const key = bits === undefined ? `p:${left.id}:${right.id}` : 'b:' + bits;
        if (this.interned.has(key)) return this.interned.get(key);
        const node = { id: this.nodes.length, length, bits, left, right };
        this.nodes.push(node); this.interned.set(key, node); return node;
    }
}

export function flatten(node) {
    if (node.bits !== undefined) return node.bits;
    return flatten(node.left) + flatten(node.right);
}

export function buildGraph(captured, expanded = false) {
    const graph = new Graph(), memo = new Map(), literals = new Map();
    const levels = [null, level(0n), level(2n), level(7n)];
    const literal = (depth, value) => {
        if (depth === 0) return graph.literal(String(value));
        const key = `${depth}:${value}`;
        if (literals.has(key)) return literals.get(key);
        const word = toArray(levels[depth].decode(value));
        // Use the same sorted-prefix Patricia construction as SUL hash levels
        // to expose structure inside the exact literal codes for this experiment.
        const trie = patriciaTrie((a, b, storage) => [graph.pair(a, b), storage]);
        let state = [null, []];
        for (const value of word.slice(0, -1)) state = trie.push([value, literal(depth - 1, value)], state);
        const result = graph.pair(trie.end(state)[0], literal(depth - 1, word.at(-1)));
        literals.set(key, result); return result;
    };
    const visit = id => {
        if (memo.has(id)) return memo.get(id);
        let node;
        if (isHash(id) || (expanded && isRaw(id))) {
            const children = captured.merges.get(id);
            if (!children) throw new Error('Missing captured SUL merge');
            node = graph.pair(visit(children[0]), visit(children[1]));
        } else if (expanded) node = literal(3, id);
        else node = graph.literal(literalBits(id));
        memo.set(id, node); return node;
    };
    return { root: visit(captured.root), nodes: graph.nodes };
}

export function reachable(root) {
    const seen = new Set(), postorder = [];
    const visit = node => {
        if (seen.has(node.id)) return;
        seen.add(node.id);
        if (node.left) { visit(node.left); visit(node.right); }
        postorder.push(node);
    };
    visit(root); return postorder;
}

export function selectRules(root, minimumBits) {
    const nodes = reachable(root), counts = new Map([[root.id, 1]]);
    for (const node of [...nodes].reverse()) if (node.left) {
        const n = counts.get(node.id) ?? 0;
        for (const child of [node.left, node.right]) counts.set(child.id, (counts.get(child.id) ?? 0) + n);
    }
    const chosen = new Set(nodes.filter(n => n.length >= minimumBits && counts.get(n.id) > 1).map(n => n.id));
    // A repeated parent is emitted only once. Recount after this pruning so
    // descendants hidden inside that parent are not credited with false savings.
    for (;;) {
        const uses = new Map(), descended = new Set();
        const visit = node => {
            if (chosen.has(node.id)) {
                uses.set(node.id, (uses.get(node.id) ?? 0) + 1);
                if (descended.has(node.id)) return;
                descended.add(node.id);
            }
            if (node.left) { visit(node.left); visit(node.right); }
        };
        visit(root);
        let removed = 0;
        for (const id of chosen) if ((uses.get(id) ?? 0) < 2) { chosen.delete(id); removed++; }
        if (!removed) return chosen;
    }
}
