import { ArithmeticEncoder, ArithmeticDecoder, RawEncoder, RawDecoder, Writer, Reader } from './arithmetic.mjs';
import { flatten, selectRules, bitsToBytes, bytesToBits } from './sul-graph.mjs';

const MAGIC = Buffer.from('SULC'), HEADER = 14;
const CONCAT = 0, LITERAL = 1, DEFINE = 2, REFERENCE = 3;

function envelope(mode, length, payload) {
    if (length >= 2 ** 32 || payload.length >= 2 ** 32) throw new Error('Prototype size limit');
    const header = Buffer.alloc(HEADER); MAGIC.copy(header); header[4] = 1; header[5] = mode;
    header.writeUInt32BE(length, 6); header.writeUInt32BE(payload.length, 10);
    return Buffer.concat([header, payload]);
}

export const rawDocument = bits => envelope(0, bits.length, bitsToBytes(bits));

export function arithmeticDocument(bits) {
    const coder = new ArithmeticEncoder(), writer = new Writer(coder);
    writer.literals(bits);
    return envelope(3, bits.length, coder.finish());
}

export function encodeGraph(root, originalLength, { minimumBits = 64, arithmetic = true, chosen = selectRules(root, minimumBits) } = {}) {
    const coder = arithmetic ? new ArithmeticEncoder() : new RawEncoder();
    const writer = new Writer(coder), dictionary = new Map(), hasChosen = new Map();
    const stats = { definitions: 0, references: 0, concatenations: 0, literalRuns: 0, literalBits: 0, minimumBits, arithmetic };
    const contains = node => {
        if (hasChosen.has(node.id)) return hasChosen.get(node.id);
        const result = chosen.has(node.id) || !!(node.left && (contains(node.left) || contains(node.right)));
        hasChosen.set(node.id, result); return result;
    };
    const body = node => {
        if (node.left && (contains(node.left) || contains(node.right))) {
            stats.concatenations++; writer.tag(CONCAT); visit(node.left); visit(node.right);
        } else {
            const bits = flatten(node);
            stats.literalRuns++; stats.literalBits += bits.length;
            writer.tag(LITERAL); writer.uint(bits.length, 64); writer.literals(bits);
        }
    };
    const visit = node => {
        if (!chosen.has(node.id)) return body(node);
        if (dictionary.has(node.id)) {
            stats.references++; writer.tag(REFERENCE);
            writer.uint(dictionary.size - 1 - dictionary.get(node.id), 128); return;
        }
        stats.definitions++; writer.tag(DEFINE);
        dictionary.set(node.id, dictionary.size); body(node);
    };
    visit(root);
    const encoded = envelope(arithmetic ? 2 : 1, originalLength, coder.finish());
    return { encoded, stats };
}

export function decodeDocument(buffer, { maxOutputBits = 64 * 1024 * 1024 } = {}) {
    if (buffer.length < HEADER || !buffer.subarray(0, 4).equals(MAGIC) || buffer[4] !== 1) throw new Error('Invalid prototype header');
    const mode = buffer[5], length = buffer.readUInt32BE(6), size = buffer.readUInt32BE(10);
    if (size !== buffer.length - HEADER || length > maxOutputBits) throw new Error('Length limit or truncated payload');
    const payload = buffer.subarray(HEADER);
    if (mode === 0) { if (payload.length !== Math.ceil(length / 8)) throw new Error('Bad raw length'); return bytesToBits(payload).slice(0, length); }
    if (![1, 2, 3].includes(mode)) throw new Error('Unknown mode');
    const reader = new Reader(mode === 1 ? new RawDecoder(payload) : new ArithmeticDecoder(payload));
    if (mode === 3) return reader.literals(length);
    const dictionary = [], limit = Math.min(maxOutputBits + 65536, length * 16 + 65536);
    let operations = 0;
    const visit = (depth = 0) => {
        if (depth > 2048 || ++operations > limit * 4 + 1024) throw new Error('Decode budget exceeded');
        switch (reader.tag()) {
            case CONCAT: {
                const a = visit(depth + 1), b = visit(depth + 1);
                if (a.length + b.length > limit) throw new Error('Expansion exceeds budget');
                return a + b;
            }
            case LITERAL: {
                const n = reader.uint(64); if (n > limit) throw new Error('Literal exceeds budget');
                return reader.literals(n);
            }
            case DEFINE: {
                const index = dictionary.length; dictionary.push(null);
                const bits = visit(depth + 1); dictionary[index] = bits; return bits;
            }
            case REFERENCE: {
                const distance = reader.uint(128), index = dictionary.length - 1 - distance;
                if (index < 0 || dictionary[index] == null) throw new Error('Invalid or cyclic reference');
                return dictionary[index];
            }
        }
    };
    const bits = visit();
    if (bits.length <= length || !/^10*$/.test(bits.slice(length))) throw new Error('Invalid SUL end padding');
    return bits.slice(0, length);
}
