import test from 'node:test';
import assert from 'node:assert/strict';
import { ArithmeticEncoder, ArithmeticDecoder } from './arithmetic.mjs';
import { capture, buildGraph, flatten } from './sul-graph.mjs';
import { rawDocument, arithmeticDocument, encodeGraph, decodeDocument } from './codec.mjs';

test('arithmetic coder: balanced, skewed, and rescaled contexts', () => {
    let seed = 123456789;
    for (const kind of ['random', 'zero', 'alternating']) {
        const encoder = new ArithmeticEncoder(), pairs = [];
        for (let i = 0; i < 70000; i++) {
            seed ^= seed << 13; seed ^= seed >>> 17; seed ^= seed << 5;
            const bit = kind === 'random' ? (seed >>> 0) & 1 : kind === 'zero' ? 0 : i & 1;
            const context = kind === 'random' ? i % 7 : 0;
            pairs.push([bit, context]); encoder.bit(bit, context);
        }
        const decoder = new ArithmeticDecoder(encoder.finish());
        for (const [bit, context] of pairs) assert.equal(decoder.bit(context), bit);
    }
});

test('all 511 short bitstrings round-trip with both SUL graph forms and coders', () => {
    for (let n = 0; n <= 8; n++) for (let x = 0; x < 2 ** n; x++) {
        const bits = n ? x.toString(2).padStart(n, '0') : '';
        assert.equal(decodeDocument(rawDocument(bits)), bits);
        assert.equal(decodeDocument(arithmeticDocument(bits)), bits);
        const captured = capture(bits);
        for (const expanded of [false, true]) {
            const { root } = buildGraph(captured, expanded);
            assert.equal(flatten(root).slice(0, n), bits);
            for (const arithmetic of [false, true]) {
                const { encoded } = encodeGraph(root, n, { minimumBits: 2, arithmetic });
                assert.equal(decodeDocument(encoded), bits);
            }
        }
    }
});

test('repeated and irregular long bitstrings round-trip; nested rules are valid', () => {
    let seed = 42;
    const random = Array.from({ length: 65537 }, () => { seed ^= seed << 13; seed ^= seed >>> 17; seed ^= seed << 5; return String((seed >>> 0) & 1); }).join('');
    const patterns = ['0'.repeat(40000), '10110010'.repeat(4096), random, random.slice(0, 4096).repeat(16)];
    for (const bits of patterns) {
        const captured = capture(bits);
        for (const expanded of [false, true]) {
            const { root } = buildGraph(captured, expanded);
            for (const minimumBits of [16, 64, 256]) for (const arithmetic of [false, true]) {
                const { encoded } = encodeGraph(root, bits.length, { minimumBits, arithmetic });
                assert.equal(decodeDocument(encoded), bits);
            }
        }
    }
});

test('frame rejects truncated payload and respects declared output limit', () => {
    const data = arithmeticDocument('01101010');
    assert.throws(() => decodeDocument(data.subarray(0, -1)));
    assert.throws(() => decodeDocument(data, { maxOutputBits: 7 }));
});
