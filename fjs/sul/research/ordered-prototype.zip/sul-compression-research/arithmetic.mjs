// Adaptive binary arithmetic coder. 32-bit intervals; products remain exact
// within JavaScript's 53-bit integer precision because totals are <= 16384.
const HALF = 0x80000000, QUARTER = 0x40000000, THREE_QUARTERS = 0xc0000000;

class BitsOut {
    bytes = []; byte = 0; count = 0;
    push(bit) {
        this.byte = this.byte * 2 + bit;
        if (++this.count === 8) { this.bytes.push(this.byte); this.byte = 0; this.count = 0; }
    }
    finish() {
        if (this.count) this.bytes.push(this.byte * 2 ** (8 - this.count));
        return Buffer.from(this.bytes);
    }
}

class Models {
    models = new Map();
    get(context) {
        let model = this.models.get(context);
        if (!model) { model = [1, 1]; this.models.set(context, model); }
        return model;
    }
    update(model, bit) {
        model[bit]++;
        if (model[0] + model[1] >= 16384) {
            model[0] = Math.ceil(model[0] / 2);
            model[1] = Math.ceil(model[1] / 2);
        }
    }
}

export class ArithmeticEncoder extends Models {
    low = 0; high = 0xffffffff; pending = 0; output = new BitsOut();
    emit(bit) {
        this.output.push(bit);
        while (this.pending) { this.output.push(1 - bit); this.pending--; }
    }
    bit(bit, context) {
        const model = this.get(context), range = this.high - this.low + 1;
        const split = this.low + Math.floor(range * model[0] / (model[0] + model[1]));
        if (bit === 0) this.high = split - 1; else this.low = split;
        for (;;) {
            if (this.high < HALF) this.emit(0);
            else if (this.low >= HALF) { this.emit(1); this.low -= HALF; this.high -= HALF; }
            else if (this.low >= QUARTER && this.high < THREE_QUARTERS) {
                this.pending++; this.low -= QUARTER; this.high -= QUARTER;
            } else break;
            this.low *= 2; this.high = this.high * 2 + 1;
        }
        this.update(model, bit);
    }
    finish() { this.pending++; this.emit(this.low < QUARTER ? 0 : 1); return this.output.finish(); }
}

export class ArithmeticDecoder extends Models {
    low = 0; high = 0xffffffff; value = 0; position = 0;
    constructor(bytes) { super(); this.bytes = bytes; for (let i = 0; i < 32; i++) this.value = this.value * 2 + this.read(); }
    read() {
        const p = this.position++;
        return p >= this.bytes.length * 8 ? 0 : (this.bytes[p >> 3] >> (7 - (p & 7))) & 1;
    }
    bit(context) {
        const model = this.get(context), range = this.high - this.low + 1;
        const split = this.low + Math.floor(range * model[0] / (model[0] + model[1]));
        const bit = this.value >= split ? 1 : 0;
        if (bit === 0) this.high = split - 1; else this.low = split;
        for (;;) {
            if (this.high < HALF) { /* no translation */ }
            else if (this.low >= HALF) { this.value -= HALF; this.low -= HALF; this.high -= HALF; }
            else if (this.low >= QUARTER && this.high < THREE_QUARTERS) {
                this.value -= QUARTER; this.low -= QUARTER; this.high -= QUARTER;
            } else break;
            this.low *= 2; this.high = this.high * 2 + 1; this.value = this.value * 2 + this.read();
        }
        this.update(model, bit);
        return bit;
    }
}

export class RawEncoder { output = new BitsOut(); bit(bit) { this.output.push(bit); } finish() { return this.output.finish(); } }
export class RawDecoder {
    position = 0;
    constructor(bytes) { this.bytes = bytes; }
    bit() { const p = this.position++; if (p >= this.bytes.length * 8) throw new Error('Truncated raw stream'); return (this.bytes[p >> 3] >> (7 - (p & 7))) & 1; }
}

// Separate adaptive models for syntax, integer prefixes, reference distances,
// and literal bits. Literal context is the previous eight transmitted bits.
export class Writer {
    history = 0;
    constructor(coder) { this.coder = coder; }
    tag(tag) { this.coder.bit(tag >> 1, 0); this.coder.bit(tag & 1, 1 + (tag >> 1)); }
    uint(value, context) {
        const bits = (value + 1).toString(2), n = bits.length - 1;
        for (let i = 0; i < n; i++) this.coder.bit(1, context + Math.min(i, 31));
        this.coder.bit(0, context + Math.min(n, 31));
        for (let i = 1; i < bits.length; i++) this.coder.bit(Number(bits[i]), context + 32 + Math.min(i - 1, 31));
    }
    literals(bits) {
        for (const char of bits) { const bit = Number(char); this.coder.bit(bit, 1024 + this.history); this.history = ((this.history << 1) | bit) & 255; }
    }
}

export class Reader {
    history = 0;
    constructor(coder) { this.coder = coder; }
    tag() { const hi = this.coder.bit(0); return hi * 2 + this.coder.bit(1 + hi); }
    uint(context) {
        let n = 0;
        while (this.coder.bit(context + Math.min(n, 31))) { if (++n > 31) throw new Error('Integer limit exceeded'); }
        let value = 1;
        for (let i = 0; i < n; i++) value = value * 2 + this.coder.bit(context + 32 + i);
        return value - 1;
    }
    literals(length) {
        let out = '';
        for (let i = 0; i < length; i++) { const bit = this.coder.bit(1024 + this.history); this.history = ((this.history << 1) | bit) & 255; out += bit; }
        return out;
    }
}
