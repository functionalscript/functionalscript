import fs from 'node:fs';
import assert from 'node:assert/strict';
import { capture, buildGraph, bytesToBits, bitsToBytes } from './sul-graph.mjs';
import { rawDocument, arithmeticDocument, encodeGraph, decodeDocument } from './codec.mjs';

const [command, input, output] = process.argv.slice(2);
if (!['compress', 'decompress'].includes(command) || !input || !output) {
    console.error('Usage: node cli.mjs compress|decompress INPUT OUTPUT'); process.exit(1);
}
const bytes = fs.readFileSync(input);
if (command === 'decompress') {
    const bits = decodeDocument(bytes);
    if (bits.length % 8) throw new Error('The decoded document is not byte-aligned');
    fs.writeFileSync(output, bitsToBytes(bits));
} else {
    const bits = bytesToBits(bytes), captured = capture(bits);
    let best = { name: 'raw', encoded: rawDocument(bits) };
    const plain = arithmeticDocument(bits);
    if (plain.length < best.encoded.length) best = { name: 'arithmetic-only', encoded: plain };
    for (const expanded of [false, true]) {
        const { root } = buildGraph(captured, expanded);
        for (const minimumBits of [16, 32, 64, 128, 256]) for (const arithmetic of [false, true]) {
            const candidate = encodeGraph(root, bits.length, { minimumBits, arithmetic });
            if (candidate.encoded.length < best.encoded.length) best = { name: `${expanded ? 'expanded' : 'native'}-SUL/${minimumBits}/${arithmetic ? 'arith' : 'raw'}`, ...candidate };
        }
    }
    assert.equal(decodeDocument(best.encoded), bits);
    fs.writeFileSync(output, best.encoded);
    console.log(JSON.stringify({ inputBytes: bytes.length, compressedBytes: best.encoded.length, selected: best.name }));
}
