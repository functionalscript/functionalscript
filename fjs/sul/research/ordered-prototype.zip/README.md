# Ordered SUL dictionary compression experiment

This archive preserves the original depth-first baseline and the follow-up that
compresses first-occurrence dictionaries jointly at lower levels. Both use the
vendored SUL snapshot at d16a9ebf39b30a42e1b795bc329774d867196841.

Extract outside a FunctionalScript checkout. With Node.js 24, from this directory:

```bash
node --test sul-compression-research/test.mjs sul-ordered-experiment/test.mjs
node sul-ordered-experiment/benchmark.mjs
node sul-ordered-experiment/cli.mjs compress INPUT OUTPUT.sulo
node sul-ordered-experiment/cli.mjs decompress OUTPUT.sulo RESTORED
```

No npm installation is required. The ordered benchmark shares the original
fixture generator and adds repeated/unique sentence fixtures. It tries native
word generations and expanded Patricia-height frontiers, each with and without
recursive dictionary deduplication. Arithmetic models adapt after each bit.
Reference recipes use independent streams and may fall back to raw coding.

sul-ordered-experiment/results/results.json contains all measurements and all
candidate cost comparisons. summary.csv is the compact comparison. Rerunning
the benchmark regenerates forty .sulo outputs and checks their decoding. Timings
vary; input hashes and encoded sizes are reproducible on the recorded runtime.
The original results and benchmark remain in sul-compression-research/results/.
Generated encoded outputs are omitted from the archive.

The top-level report.md contains the analysis. Its repository-relative artifact
links refer to the FunctionalScript research directory; the corresponding source
and complete result data are included here. The original dependency license is
sul-compression-research/vendor/LICENSE. This is a research codec with in-memory
graphs and basic resource limits, without an integrity checksum or a supported
production archive format.
