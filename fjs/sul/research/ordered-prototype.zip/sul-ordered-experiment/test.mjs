import test from 'node:test';
import assert from 'node:assert/strict';
import { wordTree, binaryTree, flatten } from './levels.mjs';
import { encodeOrdered, decodeOrdered, dictionary } from './ordered.mjs';

test('every short bitstring preserves native SUL identity and round-trips', () => {
    for (let length = 0; length <= 8; length++) for (let value = 0; value < 2 ** length; value++) {
        const bits = length ? value.toString(2).padStart(length, '0') : '';
        const { root } = wordTree(bits);
        for (const recursive of [false, true]) {
            const result = encodeOrdered(root, bits.length, { recursive });
            assert.equal(decodeOrdered(result.encoded), bits);
            assert.ok(result.encoded.length <= 14 + Math.ceil(bits.length / 8));
        }
    }
});

const fixtureTree = () => {
    let seed = 123456789;
    const random = n => Array.from({ length: n }, () => {
        seed ^= seed << 13; seed ^= seed >>> 17; seed ^= seed << 5;
        return String((seed >>> 0) & 1);
    }).join('');
    const a = { key: 'a', level: 0, length: 512, bits: random(512) };
    const b = { key: 'b', level: 0, length: 512, bits: random(512) };
    const c = { key: 'c', level: 0, length: 512, bits: random(512) };
    const parents = [[a, b, a, c], [b, c, a, b], [c, a, b, a]].map((children, i) => ({ key: `p${i}`, level: 1, length: 2048, children }));
    const sequence = Array.from({ length: 256 }, (_, i) => parents[(i * 7 + (i >> 2)) % 3]);
    return { root: { key: 'root', level: 2, length: sequence.length * 2048, children: sequence }, parents, sequence };
};

test('dictionary follows first occurrence and recursively compresses shared child contents', () => {
    const { root, parents, sequence } = fixtureTree();
    const d = dictionary(sequence);
    assert.deepEqual(d.entries, [parents[0], parents[1], parents[2]]);
    assert.deepEqual(d.references.slice(0, 4), [0, 1, 2, 0]);
    const flat = encodeOrdered(root, root.length, { recursive: false });
    const recursive = encodeOrdered(root, root.length);
    assert.equal(decodeOrdered(flat.encoded), flatten(root));
    assert.equal(decodeOrdered(recursive.encoded), flatten(root));
    assert.ok(recursive.encoded.length < flat.encoded.length);
    assert.deepEqual(recursive.layers.map(layer => layer.level), [1, 0]);
});

test('unique upper-level entries do not prevent deduplication at a lower level', () => {
    const { parents } = fixtureTree();
    const root = { key: 'unique-root', level: 2, length: 6144, children: parents };
    const result = encodeOrdered(root, root.length);
    assert.equal(decodeOrdered(result.encoded), flatten(root));
    assert.deepEqual(result.layers.map(layer => layer.level), [0]);
});

test('raw recipe streams also decode nested dictionaries', () => {
    const { root } = fixtureTree();
    const result = encodeOrdered(root, root.length, { recipeModes: [false] });
    assert.equal(decodeOrdered(result.encoded), flatten(root));
    assert.ok(result.layers.length > 1);
    assert.ok(result.layers.every(layer => layer.recipeMode === 'raw'));
});

test('large SUL input with a non-byte-aligned ending round-trips', () => {
    const bits = '001001110101101'.repeat(1024) + '101';
    const { root } = wordTree(bits);
    const result = encodeOrdered(root, bits.length);
    assert.equal(decodeOrdered(result.encoded), bits);
    assert.throws(() => decodeOrdered(result.encoded.subarray(0, -1)));
    assert.throws(() => decodeOrdered(result.encoded, { maxOutputBits: bits.length - 1 }));
});

test('expanded Patricia frontiers carry shorter subtrees and preserve bits', () => {
    const bits = '010110001101'.repeat(2048) + '11001';
    const { captured } = wordTree(bits), root = binaryTree(captured);
    for (const recursive of [false, true]) {
        const result = encodeOrdered(root, bits.length, { recursive });
        assert.equal(decodeOrdered(result.encoded), bits);
    }
});
