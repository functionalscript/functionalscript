import fs from 'node:fs';
import assert from 'node:assert/strict';
import { bytesToBits, bitsToBytes } from '../sul-compression-research/sul-graph.mjs';
import { wordTree, binaryTree } from './levels.mjs';
import { encodeOrdered, decodeOrdered } from './ordered.mjs';

const [action, input, output] = process.argv.slice(2);
if (!input || !output || !['compress', 'decompress'].includes(action)) throw new Error('Usage: node cli.mjs compress|decompress INPUT OUTPUT');
if (action === 'compress') {
    const bits = bytesToBits(fs.readFileSync(input)), { root, captured } = wordTree(bits);
    const candidates = [['word', root], ['binary', binaryTree(captured)]].map(([family, tree]) => ({ ...encodeOrdered(tree, bits.length), family }));
    const result = candidates.sort((a, b) => a.encoded.length - b.encoded.length)[0];
    assert.equal(decodeOrdered(result.encoded), bits);
    fs.writeFileSync(output, result.encoded);
    console.log(JSON.stringify({ bytes: result.encoded.length, family: result.family, levels: result.layers.map(x=>x.level), literalMode: result.literalMode }));
} else fs.writeFileSync(output, bitsToBytes(decodeOrdered(fs.readFileSync(input))));
