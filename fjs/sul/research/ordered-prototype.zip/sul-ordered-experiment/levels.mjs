// Preserve actual SUL word generations, rather than Patricia binary depth.
import { level, emptyEncodeState as emptyLiteral } from '../sul-compression-research/vendor/fjs/sul/level/literal/module.f.mjs';
import { encode as hashEncode, emptyEncodeState as emptyHash } from '../sul-compression-research/vendor/fjs/sul/level/hash/module.f.mjs';
import { capture, buildGraph, flatten as flattenGraph } from '../sul-compression-research/sul-graph.mjs';

export function flatten(node) {
    if (node.bits === undefined) node.bits = node.children.map(flatten).join('');
    return node.bits;
}

// The previous experiment's expanded Patricia graph, cut by subtree height.
// A frontier may include shorter nodes; those carry through until their height
// is reached, preserving their order and content while larger nodes expand.
export function binaryTree(captured) {
    const graph = buildGraph(captured, true), memo = new Map();
    const visit = node => {
        if (memo.has(node.id)) return memo.get(node.id);
        const children = node.left ? [visit(node.left), visit(node.right)] : undefined;
        const result = { key: `binary:${node.id}`, level: children ? 1 + Math.max(...children.map(x => x.level)) : 0, length: node.length, bits: node.bits, children };
        memo.set(node.id, result); return result;
    };
    return visit(graph.root);
}

export function wordTree(bits) {
    const captured = capture(bits);
    const padded = flattenGraph(buildGraph(captured).root);
    const leaves = [0, 1].map(value => ({ key: `0:${value}`, value: BigInt(value), level: 0, length: 1, bits: String(value) }));
    let sequence = [...padded].map(bit => leaves[Number(bit)]), generation = 0;
    const stats = [];
    while (generation < 3 || sequence.length > 1) {
        const literal = generation < 3;
        const step = literal ? level([0n, 2n, 7n][generation]).encode : hashEncode((_a, _b, _id, _symbol, storage) => storage);
        let state = literal ? emptyLiteral : emptyHash(null), pending = [];
        const next = [], interned = new Map();
        for (const child of sequence) {
            pending.push(child);
            const [value, newState] = step(child.value, state); state = newState;
            if (value === undefined) continue;
            let node = interned.get(value);
            if (!node) {
                node = { key: `${generation + 1}:${value}`, value, level: generation + 1, length: pending.reduce((n, x) => n + x.length, 0), children: pending };
                interned.set(value, node);
            }
            next.push(node); pending = [];
        }
        if (pending.length || !next.length || next.length >= sequence.length) throw new Error('SUL level did not finish or shrink');
        generation++;
        stats.push({ level: generation, symbols: next.length, unique: interned.size });
        sequence = next;
    }
    const root = sequence[0];
    if (root.value !== captured.root || flatten(root) !== padded) throw new Error('Word hierarchy differs from native SUL root');
    return { root, stats, paddedBits: padded.length, captured };
}
