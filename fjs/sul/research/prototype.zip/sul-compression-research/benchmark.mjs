import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { gzipSync, gunzipSync, brotliCompressSync, brotliDecompressSync, zstdCompressSync, zstdDecompressSync, constants } from 'node:zlib';
import { fileURLToPath } from 'node:url';
import { capture, buildGraph, bytesToBits, reachable } from './sul-graph.mjs';
import { arithmeticDocument, rawDocument, encodeGraph, decodeDocument } from './codec.mjs';

const directory = path.dirname(fileURLToPath(import.meta.url));
const output = path.join(directory, 'results'); fs.mkdirSync(output, { recursive: true });
const walk = dir => fs.readdirSync(dir, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name, 'en')).flatMap(entry => entry.isDirectory() ? walk(path.join(dir, entry.name)) : [path.join(dir, entry.name)]);
const randomBytes = (length, initial) => {
    let seed = initial; const result = Buffer.alloc(length);
    for (let i = 0; i < length; i++) { seed ^= seed << 13; seed ^= seed >>> 17; seed ^= seed << 5; result[i] = (seed >>> 0) & 255; }
    return result;
};
const repeatTo = (buffer, size) => Buffer.concat(Array.from({ length: Math.ceil(size / buffer.length) }, () => buffer)).subarray(0, size);
const sourcePaths = walk(path.join(directory, 'vendor')).filter(p => p.endsWith('.mjs'));
const source = Buffer.concat(sourcePaths.map(p => fs.readFileSync(p))).subarray(0, 65536);
const recordRows = Array.from({ length: 640 }, (_, i) => JSON.stringify({ id: i, type: 'measurement', sensor: i % 16, timestamp: 1700000000 + i, value: (i * 37) % 1000, status: i % 9 ? 'ok' : 'retry' }) + '\n');
const exactBlock = randomBytes(4096, 91234);
const versions = [];
for (let i = 0; i < 32; i++) { const v = Buffer.from(exactBlock); v[(i * 113) % v.length] ^= (i + 1); versions.push(v); }
const biased = Buffer.alloc(65536), noise = randomBytes(65536, 7890);
for (let i = 0; i < biased.length; i++) if (noise[i] < 20) biased[i] = 1 << (noise[i] & 7);
let recursive = '0'; for (let i = 0; i < 16; i++) recursive += [...recursive].map(x => x === '0' ? '1' : '0').join('');
const fixtures = [
    ['source_code', source, 'First 64 KiB of sorted concatenated vendored FunctionalScript modules, including proofs.'],
    ['json_records', Buffer.from(recordRows.join('')), '640 generated JSON records with changing numeric fields.'],
    ['repeated_phrase', repeatTo(Buffer.from('Immutable documents share identical subtrees. Arithmetic coding represents frequent events with fewer bits.\n'), 65536), 'One 108-byte phrase repeated and truncated.'],
    ['repeated_random_block', repeatTo(exactBlock, 131072), 'A generated 4 KiB pseudorandom block repeated 32 times.'],
    ['edited_versions', Buffer.concat(versions), '32 versions of that 4 KiB block; each has one independent byte substitution.'],
    ['recursive_sequence', Buffer.from(recursive), '16 Thue-Morse expansion rounds, stored as ASCII 0/1.'],
    ['biased_bits', biased, 'Generated sparse bytes: approximately 1% of bits are set.'],
    ['uniform_random', randomBytes(65536, 123456789), 'Xorshift32 pseudorandom byte stream; incompressibility control.'],
];

const report = { version: 1, node: process.version, sulCommit: 'd16a9ebf39b30a42e1b795bc329774d867196841', minRuleBits: [16, 32, 64, 128, 256], fixtures: [] };
for (const [name, bytes, description] of fixtures) {
    const bits = bytesToBits(bytes), start = performance.now(), captured = capture(bits), captureMs = performance.now() - start;
    const row = { name, description, inputBytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex'), captureMs, candidates: [] };
    const plain = arithmeticDocument(bits); assert.equal(decodeDocument(plain), bits); row.arithmeticOnlyBytes = plain.length;
    for (const [family, expanded] of [['native', false], ['expanded', true]]) {
        const graphStart = performance.now(), { root } = buildGraph(captured, expanded);
        row[family + 'GraphMs'] = performance.now() - graphStart;
        row[family + 'UniqueNodes'] = reachable(root).length;
        for (const minimumBits of report.minRuleBits) {
            for (const arithmetic of [false, true]) {
                const before = performance.now();
                const { encoded, stats } = encodeGraph(root, bits.length, { minimumBits, arithmetic });
                const encodeMs = performance.now() - before, decodeStart = performance.now();
                assert.equal(decodeDocument(encoded), bits);
                const candidate = { family, minimumBits, arithmetic, bytes: encoded.length, encodeMs, decodeMs: performance.now() - decodeStart, ...stats };
                row.candidates.push(candidate);
                fs.writeFileSync(path.join(output, `${name}-${family}-${minimumBits}-${arithmetic ? 'arith' : 'raw'}.sulc`), encoded);
            }
        }
    }
    for (const [label, compress, decompress] of [
        ['gzip9', b => gzipSync(b, { level: 9 }), gunzipSync],
        ['brotli5', b => brotliCompressSync(b, { params: { [constants.BROTLI_PARAM_QUALITY]: 5 } }), brotliDecompressSync],
        ['brotli11', b => brotliCompressSync(b, { params: { [constants.BROTLI_PARAM_QUALITY]: 11 } }), brotliDecompressSync],
        ['zstd3', b => zstdCompressSync(b, { params: { [constants.ZSTD_c_compressionLevel]: 3 } }), zstdDecompressSync],
        ['zstd19', b => zstdCompressSync(b, { params: { [constants.ZSTD_c_compressionLevel]: 19 } }), zstdDecompressSync]
    ]) {
        const before = performance.now(), compressed = compress(bytes);
        row[label + 'Bytes'] = compressed.length; row[label + 'Ms'] = performance.now() - before;
        assert.deepEqual(decompress(compressed), bytes);
    }
    const best = (family, arithmetic) => row.candidates.filter(c => c.family === family && c.arithmetic === arithmetic).sort((a, b) => a.bytes - b.bytes)[0];
    row.nativeRaw = best('native', false); row.nativeArithmetic = best('native', true);
    row.expandedRaw = best('expanded', false); row.expandedArithmetic = best('expanded', true);
    row.bestGrammarBytes = Math.min(row.nativeArithmetic.bytes, row.expandedArithmetic.bytes);
    row.hybridBytes = Math.min(row.bestGrammarBytes, row.nativeRaw.bytes, row.expandedRaw.bytes, plain.length, rawDocument(bits).length);
    row.totalMs = performance.now() - start;
    report.fixtures.push(row);
    fs.writeFileSync(path.join(output, 'results.json'), JSON.stringify(report, null, 2));
    console.log(JSON.stringify({ name, input: bytes.length, native: row.nativeArithmetic.bytes, expanded: row.expandedArithmetic.bytes, arithmetic: plain.length, hybrid: row.hybridBytes, gzip: row.gzip9Bytes, brotli11: row.brotli11Bytes, zstd19: row.zstd19Bytes, seconds: +(row.totalMs / 1000).toFixed(2) }));
}
const fields = ['name', 'inputBytes', 'arithmeticOnlyBytes', 'bestGrammarBytes', 'hybridBytes', 'gzip9Bytes', 'brotli5Bytes', 'brotli11Bytes', 'zstd3Bytes', 'zstd19Bytes', 'captureMs', 'totalMs'];
fs.writeFileSync(path.join(output, 'summary.csv'), fields.join(',') + '\n' + report.fixtures.map(r => fields.map(k => r[k]).join(',')).join('\n') + '\n');
console.log('All compressed candidates and baseline outputs reconstructed the original inputs.');
