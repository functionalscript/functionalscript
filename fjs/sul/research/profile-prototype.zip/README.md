# Shared frequency-profile registry experiment

An isolated research prototype. It changes probability models and adds a model
reference to the compressed representation; it does not change the SUL alphabet,
subtree identities, first-occurrence dictionary ordering, or source documents.
The directory is a local registry prototype, not a deployed registry service.

Use Node.js 24.19.0 from the extracted archive root. No npm installation is needed:

```sh
node --test sul-profile-experiment/test.mjs
node sul-profile-experiment/train.mjs
node sul-profile-experiment/benchmark.mjs
node sul-profile-experiment/cli.mjs encode INPUT OUTPUT.sulp
node sul-profile-experiment/cli.mjs decode OUTPUT.sulp RESTORED
```

The archive already contains all corpus files and their licenses, four trained
profiles, a registry, and measured results. Training deterministically recreates
the profiles. The corpus-selection Python script is provenance: it requires the
named local source checkouts at the revisions in corpus.json. It is unnecessary
for reproduction from the archive, and it should not be run against newer sources
when comparing the recorded results.

The four profile names are generic, text, ASCII, and JSON. They are suggestions
for selection, not restrictions on what bytes each profile can decode. The
encoder tries every registered profile in fixed and prior-initialized modes, plus
the unchanged adaptive codec, choosing
the smallest complete result; adaptive wins a tie. The selected profile is fixed
for the complete document, not switched per block. A profiled stream adds 37 bytes:
SULP magic (4), coding-policy byte (1), and SHA-256 profile identifier (32), followed by a SULO
stream. An adaptive winner remains an ordinary SULO stream without that wrapper.

Profile objects are immutable canonical JSON with a model-schema version, sorted
context rows, and positive integer weights. They model the existing binary
literal and recipe contexts. Document-local dictionary ID 17 is not treated as a
globally shared word. Counts are fitted from the final adaptive training encodings,
observed during decoding; discarded candidates and raw streams provide no events.
Rows with fewer than 16 events use an implicit uniform fallback. Other rows use
add-one smoothing and weights normalized to 4096. Fixed mode (policy 1) never
updates these probabilities. The control mode (policy 2) initializes each context
with a prior totaling 16, then applies the original adaptive updates and rescaling
within that stream. It never modifies the registered profile object.

The decoder needs the exact profile selected by the encoder, identified by its
hash. It rejects missing or mismatching profiles. The CLI reads an already cached
profile; a registry service could supply these immutable objects over HTTP.

This pilot has 22 training files and 12 separate test files. Its generic profile
is a mixture of the selected source, Markdown and JSON files, not a representative
model of all binary formats. Reported warm sizes include the full model identifier;
cold sizes additionally include the profile's canonical JSON bytes. No network
protocol overhead is included. New encoded outputs are reproducible and omitted
from the archive. Fixed-profile model choices were set before inspecting test
sizes. The prior-16 control was added after observing fixed-profile losses, with
no table refitting; its results are exploratory on the same test set.

The existing ordered codec gains optional arithmetic encoder/decoder factories.
Their defaults are unchanged, and prior ordered/byte tests verify compatibility.
All other experimental files and dependency snapshots remain separately archived.
