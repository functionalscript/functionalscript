"""Recreate the pinned pilot corpus from the named local public source checkouts."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess

root = Path(__file__).resolve().parent.parent
out = Path(__file__).resolve().parent
fs = root / 'functionalscript-pr'
brotli = root / 'brotli-inspection'
ts = root / 'sul-pr-tools/node_modules/typescript'
sha = lambda data: hashlib.sha256(data).hexdigest()
tracked = subprocess.check_output(['git', 'ls-files'], cwd=fs, text=True).splitlines()
groups = {}
for category, extensions in [('source', {'.mjs', '.ts'}), ('text', {'.md'})]:
    paths = [s for s in tracked if Path(s).suffix in extensions and '/research/' not in s and 'proof' not in Path(s).name and (fs/s).is_file() and 512 <= (fs/s).stat().st_size <= 8192]
    paths.sort(key=lambda s: sha(s.encode()))
    groups[category] = [('functionalscript', fs/s, s) for s in paths[:9]]
paths = [p for p in brotli.rglob('*.c') if 512 <= p.stat().st_size <= 8192]
paths.sort(key=lambda p: sha(str(p.relative_to(brotli)).encode()))
groups['c'] = [('brotli', p, str(p.relative_to(brotli))) for p in paths[:9]]
groups['json'] = [('functionalscript', fs/s, s) for s in ['package-lock.json', 'deno.json', 'funding.json', 'package.json']] + [('brotli', brotli/'js/package.json', 'js/package.json'), ('typescript', ts/'package.json', 'package.json')]
groups['json'].sort(key=lambda x: sha((x[0] + '/' + x[2]).encode()))
files = []
(out/'corpus').mkdir(exist_ok=True)
for category, paths in groups.items():
    train_count = 4 if category == 'json' else 6
    for index, (project, path, original) in enumerate(paths):
        data = path.read_bytes()
        name = f'{category}-{index:02}'
        local = f'corpus/{name}{path.suffix}'
        (out/local).write_bytes(data)
        files.append(dict(name=name, category=category, split='train' if index < train_count else 'test', project=project, source=original, local=local, bytes=len(data), sha256=sha(data), ascii=all(b < 128 for b in data)))
path = brotli/'tests/testdata/cp1251-utf16le.compressed'
data = path.read_bytes()
(out/'corpus/binary-00.compressed').write_bytes(data)
files.append(dict(name='binary-00', category='binary', split='test', project='brotli', source=str(path.relative_to(brotli)), local='corpus/binary-00.compressed', bytes=len(data), sha256=sha(data), ascii=False))
train_hashes = {f['sha256'] for f in files if f['split'] == 'train'}
assert not train_hashes.intersection(f['sha256'] for f in files if f['split'] == 'test')
manifest = dict(version=1, selection='Source, markdown and C files: first nine by SHA-256 of relative path among whole files of 512..8192 bytes; first six train, next three test. JSON: six named real package/configuration files sorted by SHA-256(project/path), first four train and last two test. One pre-existing compressed test file is an out-of-domain control. No selection uses compressed sizes.',
    sourceRevisions=dict(functionalscript=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=fs, text=True).strip(), brotli=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=brotli, text=True).strip(), typescript=json.loads((ts/'package.json').read_text())['version']), files=files)
(out/'corpus.json').write_text(json.dumps(manifest, indent=2)+'\n')
(out/'licenses').mkdir(exist_ok=True)
for name, path in [('FunctionalScript-MIT.txt', fs/'LICENSE'), ('Brotli-MIT.txt', brotli/'LICENSE'), ('TypeScript-LICENSE.txt', ts/'LICENSE'), ('TypeScript-NOTICE.txt', ts/'NOTICE.txt')]:
    shutil.copyfile(path, out/'licenses'/name)
print(json.dumps({split: {'files': sum(f['split']==split for f in files), 'bytes': sum(f['bytes'] for f in files if f['split']==split)} for split in ['train','test']}))
