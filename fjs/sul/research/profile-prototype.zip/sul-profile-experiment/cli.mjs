import fs from 'node:fs';
import assert from 'node:assert/strict';
import { encodeBest, decode } from './codec.mjs';
import { profileId } from './profile.mjs';

const [command, input, output] = process.argv.slice(2), root = new URL('./', import.meta.url);
if (!['encode', 'decode'].includes(command) || !input || !output) throw new Error('Usage: node sul-profile-experiment/cli.mjs encode|decode INPUT OUTPUT');
const bytes = fs.readFileSync(input);
if (command === 'encode') {
    const registry = JSON.parse(fs.readFileSync(new URL('registry.json', root)));
    const profiles = registry.profiles.map(entry => ({ ...entry, profile: JSON.parse(fs.readFileSync(new URL(entry.file, root))) }));
    for (const entry of profiles) assert.equal(entry.id, 'sha256:' + profileId(entry.profile));
    const { best, candidates } = encodeBest(bytes, profiles), byId = new Map(profiles.map(p => [profileId(p.profile), p.profile]));
    assert.deepEqual(decode(best.encoded, byId), bytes);
    fs.writeFileSync(output, best.encoded);
    console.log(JSON.stringify({ selected: best.name, bytes: best.encoded.length, candidates: candidates.map(c => ({ profile: c.name, bytes: c.encoded.length })) }));
} else {
    const registry = new Map();
    if (bytes.subarray(0, 4).toString() === 'SULP' && bytes.length >= 37) {
        const id = bytes.subarray(5, 37).toString('hex');
        registry.set(id, JSON.parse(fs.readFileSync(new URL(`profiles/${id}.json`, root))));
    }
    fs.writeFileSync(output, decode(bytes, registry));
}
