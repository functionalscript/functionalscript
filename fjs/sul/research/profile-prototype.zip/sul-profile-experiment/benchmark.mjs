import fs from 'node:fs';
import assert from 'node:assert/strict';
import { brotliCompressSync, brotliDecompressSync, zstdCompressSync, zstdDecompressSync, constants } from 'node:zlib';
import { prepare, encodeBest, decode } from './codec.mjs';
import { digest, profileId } from './profile.mjs';

const root = new URL('./', import.meta.url), corpus = JSON.parse(fs.readFileSync(new URL('corpus.json', root))), registry = JSON.parse(fs.readFileSync(new URL('registry.json', root)));
const profiles = registry.profiles.map(entry => ({ ...entry, profile: JSON.parse(fs.readFileSync(new URL(entry.file, root))) }));
for (const entry of profiles) assert.equal(entry.id, 'sha256:' + profileId(entry.profile));
const byId = new Map(profiles.map(p => [profileId(p.profile), p.profile]));
fs.mkdirSync(new URL('results/', root), { recursive: true });
const report = { version: 1, node: process.version, sulCommit: 'd16a9ebf39b30a42e1b795bc329774d867196841', corpus, registry, scope: 'Four shared profiles, each fixed and as a prior of total 16, versus unchanged adaptive models. Profiled frames include a 37-byte wrapper with a full SHA-256 profile ID and coding policy. The prior control was added after the fixed-profile losses; no tables were refitted. Dictionary contents, alphabet order and SUL hierarchy construction are unchanged; optimal retained levels can change with the model.', files: [] };
for (const file of corpus.files.filter(f => f.split === 'test')) {
    const start = performance.now(), bytes = fs.readFileSync(new URL(file.local, root)); assert.equal(digest(bytes), file.sha256);
    const prepared = prepare(bytes), { best, candidates } = encodeBest(bytes, profiles, prepared);
    const row = { name: file.name, category: file.category, inputBytes: bytes.length, sha256: file.sha256, treeMs: prepared.treeMs, selected: best.name, candidates: [] };
    for (const candidate of candidates) {
        assert.deepEqual(decode(candidate.encoded, byId), bytes);
        fs.writeFileSync(new URL(`results/${file.name}-${candidate.name}.sulp`, root), candidate.encoded);
        const p = profiles.find(p => p.name === candidate.profileName);
        row.candidates.push({ name: candidate.name, profile: candidate.profileName ?? null, policy: candidate.policy ?? 'adaptive', bytes: candidate.encoded.length, innerBytes: candidate.result.encoded.length,
            coldBytes: candidate.encoded.length + (p?.bytes ?? 0), profileBytes: p?.bytes ?? 0, encodeMs: candidate.encodeMs,
            container: candidate.result.container, layers: candidate.result.layers, literalBits: candidate.result.literalBits, literalMode: candidate.result.literalMode });
    }
    row.adaptiveBytes = row.candidates[0].bytes; row.selectedBytes = best.encoded.length;
    row.bestColdBytes = Math.min(...row.candidates.map(c => c.coldBytes));
    for (const [name, encode, restore] of [
        ['brotli11', b => brotliCompressSync(b, { params: { [constants.BROTLI_PARAM_QUALITY]: 11 } }), brotliDecompressSync],
        ['zstd19', b => zstdCompressSync(b, { params: { [constants.ZSTD_c_compressionLevel]: 19 } }), zstdDecompressSync],
    ]) { const output = encode(bytes); assert.deepEqual(restore(output), bytes); row[name + 'Bytes'] = output.length; }
    row.totalMs = performance.now() - start; report.files.push(row);
    fs.writeFileSync(new URL('results/results.json', root), JSON.stringify(report, null, 2) + '\n');
    console.log(JSON.stringify({ name: row.name, category: row.category, input: row.inputBytes, adaptive: row.adaptiveBytes,
        profiles: Object.fromEntries(row.candidates.slice(1).map(c => [c.name, c.bytes])), selected: row.selected, bytes: row.selectedBytes, brotli: row.brotli11Bytes }));
}
const fields = ['name', 'category', 'inputBytes', 'adaptiveBytes', 'selected', 'selectedBytes', 'bestColdBytes', 'brotli11Bytes', 'zstd19Bytes'];
fs.writeFileSync(new URL('results/summary.csv', root), fields.join(',') + '\n' + report.files.map(r => fields.map(f => r[f]).join(',')).join('\n') + '\n');
console.log(`All ${report.files.length * 9} SUL candidates and ${report.files.length * 2} standard-codec outputs decoded exactly.`);
