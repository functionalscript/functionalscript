import fs from 'node:fs';
import assert from 'node:assert/strict';
import { prepare, encodeCandidate, decode } from './codec.mjs';
import { digest, fitProfile, mergeCounts, profileBytes, profileId } from './profile.mjs';

const root = new URL('./', import.meta.url), corpus = JSON.parse(fs.readFileSync(new URL('corpus.json', root)));
const documents = [], byCategory = new Map();
for (const file of corpus.files.filter(f => f.split === 'train')) {
    const bytes = fs.readFileSync(new URL(file.local, root)); assert.equal(digest(bytes), file.sha256);
    const counts = new Map(), encoded = encodeCandidate(bytes, undefined, prepare(bytes)).encoded;
    assert.deepEqual(decode(encoded, undefined, counts), bytes);
    documents.push({ file, counts });
    console.log(JSON.stringify({ phase: 'train', name: file.name, bytes: bytes.length, contexts: counts.size }));
}
const descriptions = {
    generic: f => true,
    text: f => f.category === 'text',
    ascii: f => f.ascii,
    json: f => f.category === 'json',
};
fs.mkdirSync(new URL('profiles/', root), { recursive: true });
const registry = { version: 1, dictionaryPolicy: 'Unchanged first-occurrence order and raw-byte SUL hierarchy. Profiles describe binary coding contexts, not document-local dictionary identities.',
    training: 'Count only arithmetic events in the final adaptive encoding, observed by decoding it. Discarded candidates and raw streams supply no events. Use add-one smoothing, at least 16 events per context, weights totaling 4096; unknown contexts use [1,1].', profiles: [] };
for (const [name, accept] of Object.entries(descriptions)) {
    const selected = documents.filter(({ file }) => accept(file)); assert(selected.length);
    const counts = mergeCounts(selected.map(d => d.counts)), profile = fitProfile(counts), id = profileId(profile), data = profileBytes(profile);
    fs.writeFileSync(new URL(`profiles/${id}.json`, root), data);
    registry.profiles.push({ name, id: 'sha256:' + id, file: `profiles/${id}.json`, bytes: data.length, rows: profile.rows.length,
        events: [...counts.values()].reduce((n, row) => n + row[0] + row[1], 0), trainingFiles: selected.map(d => d.file.name) });
}
fs.writeFileSync(new URL('registry.json', root), JSON.stringify(registry, null, 2) + '\n');
console.log(JSON.stringify(registry.profiles.map(({ name, id, bytes, rows, events }) => ({ name, id, bytes, rows, events }))));
