import { encodeOrdered, decodeOrdered } from '../sul-ordered-experiment/ordered.mjs';
import { fixedSymbolTree } from '../sul-byte-experiment/levels.mjs';
import { bytesToBits, bitsToBytes } from '../sul-compression-research/sul-graph.mjs';
import { FixedEncoder, FixedDecoder, PriorEncoder, PriorDecoder, RecordingDecoder, profileId } from './profile.mjs';

export function prepare(bytes) {
    const bits = bytesToBits(bytes), start = performance.now();
    const tree = fixedSymbolTree(bits, 8);
    return { bits, tree, treeMs: performance.now() - start };
}

export function encodeCandidate(bytes, profile, prepared = prepare(bytes), policy = 'fixed') {
    if (!['fixed', 'prior16'].includes(policy)) throw new Error('Unknown profile policy');
    const start = performance.now();
    const Encoder = policy === 'prior16' ? PriorEncoder : FixedEncoder;
    const result = encodeOrdered(prepared.tree.root, prepared.bits.length, profile ? { createEncoder: () => new Encoder(profile) } : {});
    let encoded = result.encoded;
    if (profile) {
        const header = Buffer.alloc(37); header.write('SULP'); header[4] = policy === 'prior16' ? 2 : 1; Buffer.from(profileId(profile), 'hex').copy(header, 5);
        encoded = Buffer.concat([header, encoded]);
    }
    return { encoded, result, encodeMs: performance.now() - start };
}

export function decode(bytes, registry = new Map(), counts) {
    if (bytes.subarray(0, 4).toString() === 'SULO') {
        return bitsToBytes(decodeOrdered(bytes, counts ? { createDecoder: payload => new RecordingDecoder(payload, counts) } : {}));
    }
    if (bytes.length < 51 || bytes.subarray(0, 4).toString() !== 'SULP' || ![1, 2].includes(bytes[4])) throw new Error('Invalid profile frame');
    const id = bytes.subarray(5, 37).toString('hex'), profile = registry.get(id);
    if (!profile) throw new Error('Missing frequency profile ' + id);
    if (profileId(profile) !== id) throw new Error('Frequency profile hash mismatch');
    const Decoder = bytes[4] === 2 ? PriorDecoder : FixedDecoder;
    return bitsToBytes(decodeOrdered(bytes.subarray(37), { createDecoder: payload => new Decoder(payload, profile) }));
}

export function encodeBest(bytes, profiles, prepared = prepare(bytes)) {
    const candidates = [{ name: 'adaptive', ...encodeCandidate(bytes, undefined, prepared) },
        ...profiles.flatMap(({ name, profile }) => ['fixed', 'prior16'].map(policy => ({ name: name + '-' + policy, profileName: name, policy, ...encodeCandidate(bytes, profile, prepared, policy) })))];
    // Adaptive wins a size tie, avoiding an unnecessary external dependency.
    let best = candidates[0];
    for (const candidate of candidates.slice(1)) if (candidate.encoded.length < best.encoded.length) best = candidate;
    return { best, candidates };
}
