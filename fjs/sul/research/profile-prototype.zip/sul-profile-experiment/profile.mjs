import { createHash } from 'node:crypto';
import { ArithmeticEncoder, ArithmeticDecoder } from '../sul-compression-research/arithmetic.mjs';

export const schema = 'sul-ordered-binary-contexts-v1';
export const digest = bytes => createHash('sha256').update(bytes).digest('hex');

export function validateProfile(profile) {
    if (profile.schema !== schema || profile.total !== 4096 || !Array.isArray(profile.rows)) throw new Error('Unknown profile schema');
    let previous = -1;
    for (const row of profile.rows) {
        if (!Array.isArray(row) || row.length !== 3 || !row.every(Number.isSafeInteger)) throw new Error('Invalid profile row');
        const [context, zero, one] = row;
        if (context <= previous || context < 0 || zero < 1 || one < 1 || zero + one !== profile.total) throw new Error('Invalid profile weights');
        previous = context;
    }
    return profile;
}

export const profileBytes = profile => {
    validateProfile(profile);
    return Buffer.from(JSON.stringify({ schema: profile.schema, total: profile.total, rows: profile.rows }) + '\n');
};
export const profileId = profile => digest(profileBytes(profile));
const weights = profile => new Map(validateProfile(profile).rows.map(([context, zero, one]) => [context, [zero, one]]));

export class FixedEncoder extends ArithmeticEncoder {
    constructor(profile) { super(); this.weights = weights(profile); }
    get(context) { return this.weights.get(context) ?? [1, 1]; }
    update() {}
}

export class FixedDecoder extends ArithmeticDecoder {
    constructor(bytes, profile) { super(bytes); this.weights = weights(profile); }
    get(context) { return this.weights.get(context) ?? [1, 1]; }
    update() {}
}

// The stored table remains immutable. Each stream starts with a small trained
// prior (total 16) and then uses the original adaptive updates and rescaling.
function priorModel(coder, context) {
    if (!coder.models.has(context)) {
        const source = coder.weights.get(context);
        if (source) { const zero = Math.max(1, Math.min(15, Math.round(16 * source[0] / 4096))); coder.models.set(context, [zero, 16 - zero]); }
    }
    let model = coder.models.get(context);
    if (!model) { model = [1, 1]; coder.models.set(context, model); }
    return model;
}

export class PriorEncoder extends ArithmeticEncoder {
    constructor(profile) { super(); this.weights = weights(profile); }
    get(context) { return priorModel(this, context); }
}

export class PriorDecoder extends ArithmeticDecoder {
    constructor(bytes, profile) { super(bytes); this.weights = weights(profile); }
    get(context) { return priorModel(this, context); }
}

export class RecordingDecoder extends ArithmeticDecoder {
    constructor(bytes, counts) { super(bytes); this.counts = counts; }
    bit(context) {
        const bit = super.bit(context);
        const row = this.counts.get(context) ?? [0, 0]; row[bit]++; this.counts.set(context, row);
        return bit;
    }
}

export function mergeCounts(inputs) {
    const result = new Map();
    for (const counts of inputs) for (const [context, countsRow] of counts) {
        const row = result.get(context) ?? [0, 0]; row[0] += countsRow[0]; row[1] += countsRow[1]; result.set(context, row);
    }
    return result;
}

export function fitProfile(counts, minimumEvents = 16) {
    const rows = [];
    for (const [context, [zero, one]] of [...counts].sort((a, b) => a[0] - b[0])) {
        if (zero + one < minimumEvents) continue;
        const weight = Math.max(1, Math.min(4095, Math.round(4096 * (zero + 1) / (zero + one + 2))));
        rows.push([context, weight, 4096 - weight]);
    }
    return validateProfile({ schema, total: 4096, rows });
}
