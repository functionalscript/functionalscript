import test from 'node:test';
import assert from 'node:assert/strict';
import { FixedEncoder, FixedDecoder, PriorEncoder, PriorDecoder, fitProfile, profileId, validateProfile } from './profile.mjs';
import { encodeCandidate, encodeBest, decode, prepare } from './codec.mjs';

const profile = fitProfile(new Map([[0, [999, 1]], [1024, [1000, 1]], [1152, [1, 1000]], [2049, [12, 34]]]));

test('fixed model codes rare outcomes and unseen contexts without modifying weights', () => {
    const before = JSON.stringify(profile), encoder = new FixedEncoder(profile), events = [];
    for (let i = 0; i < 1000; i++) { const context = [0, 1024, 1152, 2049, 987654][i % 5], bit = (i * 17 % 7) < 3 ? 0 : 1; events.push([context, bit]); encoder.bit(bit, context); }
    const decoder = new FixedDecoder(encoder.finish(), profile);
    for (const [context, bit] of events) assert.equal(decoder.bit(context), bit);
    assert.equal(JSON.stringify(profile), before);
});

test('profile frame requires the exact profile and preserves all byte values', () => {
    for (const bytes of [Buffer.alloc(0), Buffer.from([255]), Buffer.from(Array.from({ length: 256 }, (_, i) => i)), Buffer.from('alpha beta alpha gamma beta alpha\n'.repeat(24))]) {
        const encoded = encodeCandidate(bytes, profile).encoded, id = profileId(profile);
        assert.deepEqual(decode(encoded, new Map([[id, profile]])), bytes);
        assert.throws(() => decode(encoded), /Missing frequency profile/);
        assert.throws(() => decode(encoded, new Map([[id, fitProfile(new Map())]])), /hash mismatch/);
    }
});

test('model selection includes the profile identifier and retains adaptive fallback', () => {
    const bytes = Buffer.from('abcd'.repeat(64)), tree = prepare(bytes);
    const result = encodeBest(bytes, [{ name: 'example', profile }], tree);
    assert.equal(result.candidates[1].encoded.length, result.candidates[1].result.encoded.length + 37);
    assert(result.best.encoded.length <= result.candidates[0].encoded.length);
});

test('profiles are canonical, smoothed and validated', () => {
    const a = fitProfile(new Map([[9, [20, 0]], [3, [0, 20]]])), b = fitProfile(new Map([[3, [0, 20]], [9, [20, 0]]]));
    assert.equal(profileId(a), profileId(b));
    assert.equal(profileId(a), profileId({ rows: a.rows, total: a.total, schema: a.schema }));
    assert(a.rows.every(([, zero, one]) => zero > 0 && one > 0));
    assert.throws(() => validateProfile({ schema: a.schema, total: 4096, rows: [[0, 0, 4096]] }));
    assert.throws(() => validateProfile({ schema: 'unknown', total: 4096, rows: [] }));
});

test('trained priors adapt per stream without mutating the registered table', () => {
    const before = JSON.stringify(profile), encoder = new PriorEncoder(profile);
    const first = [...encoder.get(0)]; assert.equal(first[0] + first[1], 16);
    for (let i = 0; i < 100; i++) encoder.bit(1, 0);
    assert.equal(encoder.get(0)[1], first[1] + 100);
    const decoder = new PriorDecoder(encoder.finish(), profile);
    for (let i = 0; i < 100; i++) assert.equal(decoder.bit(0), 1);
    assert.equal(JSON.stringify(profile), before);
    const bytes = Buffer.from('one two one three two one\n'.repeat(16));
    const encoded = encodeCandidate(bytes, profile, prepare(bytes), 'prior16').encoded;
    assert.deepEqual(decode(encoded, new Map([[profileId(profile), profile]])), bytes);
});
