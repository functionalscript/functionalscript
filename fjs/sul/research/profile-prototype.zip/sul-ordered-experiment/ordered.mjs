// Research codec: first-occurrence dictionaries, jointly compressed below.
import { ArithmeticEncoder, ArithmeticDecoder, RawEncoder, RawDecoder, Writer, Reader } from '../sul-compression-research/arithmetic.mjs';
import { bitsToBytes, bytesToBits } from '../sul-compression-research/sul-graph.mjs';
import { flatten } from './levels.mjs';

const HEADER = 14;
const varint = n => {
    const bytes = [];
    do { const byte = n % 128; n = Math.floor(n / 128); bytes.push(byte + (n ? 128 : 0)); } while (n);
    return Buffer.from(bytes);
};

function literal(bits, createEncoder) {
    const coder = createEncoder(); new Writer(coder).literals(bits);
    const prefix = varint(bits.length);
    const candidates = [
        { encoded: Buffer.concat([Buffer.from([0]), prefix, bitsToBytes(bits)]), literalMode: 'raw' },
        { encoded: Buffer.concat([Buffer.from([1]), prefix, coder.finish()]), literalMode: 'arithmetic' },
    ];
    return { ...candidates.sort((a, b) => a.encoded.length - b.encoded.length)[0], layers: [], literalBits: bits.length };
}

// Binary decision-tree contexts model the reference alphabet directly. The
// first occurrence introduces the next ID implicitly; only old IDs need bits.
function writeReference(coder, value, count) {
    const width = Math.ceil(Math.log2(count));
    let prefix = 1;
    for (let bit = width - 1; bit >= 0; bit--) {
        const v = (value >>> bit) & 1;
        coder.bit(v, 2048 + prefix); prefix = prefix * 2 + v;
    }
}
function readReference(coder, count) {
    const width = Math.ceil(Math.log2(count));
    let value = 0, prefix = 1;
    for (let bit = width - 1; bit >= 0; bit--) {
        const v = coder.bit(2048 + prefix); value = value * 2 + v; prefix = prefix * 2 + v;
    }
    if (value >= count) throw new Error('Reference outside dictionary');
    return value;
}

export function dictionary(sequence) {
    const ids = new Map(), entries = [], references = [];
    for (const node of sequence) {
        if (!ids.has(node.key)) { ids.set(node.key, entries.length); entries.push(node); }
        references.push(ids.get(node.key));
    }
    return { entries, references };
}

const lower = (sequence, ceiling) => sequence.flatMap(node => node.level > ceiling ? node.children : [node]);

function recipe(entries, references, arithmetic, createEncoder) {
    const coder = arithmetic ? createEncoder() : new RawEncoder(), writer = new Writer(coder);
    writer.uint(references.length, 64); writer.uint(entries.length, 128);
    for (const node of entries) writer.uint(node.length, 256);
    let seen = 0;
    for (const id of references) {
        const fresh = id === seen;
        if (seen > 0 && seen < entries.length) coder.bit(Number(fresh), 0);
        if (fresh) seen++;
        else writeReference(coder, id, seen);
    }
    return coder.finish();
}

// A skip needs no stream marker: the lower-level recipe reconstructs the same
// bits. Both a level's recipe and its recursively compressed dictionary count
// toward the decision. Separate streams make these candidate costs additive.
export function encodeOrdered(root, originalLength, { recursive = true, recipeModes = [false, true], createEncoder = () => new ArithmeticEncoder() } = {}) {
    const memo = new Map(), trials = [];
    const compress = (source, ceiling) => {
        const key = `${ceiling}|${source.map(node => node.key).join(',')}`;
        if (memo.has(key)) return memo.get(key);
        const bits = source.map(flatten).join('');
        let best = literal(bits, createEncoder), sequence = source;
        if (ceiling >= 0) sequence = lower(source, ceiling);
        for (let generation = ceiling; generation >= 0; generation--) {
            if (sequence.some(node => node.level > generation)) throw new Error('Invalid hierarchy frontier');
            const { entries, references } = dictionary(sequence);
            if (entries.length < sequence.length) {
                const lower = recursive ? compress(entries, generation - 1) : literal(entries.map(flatten).join(''), createEncoder);
                for (const arithmetic of recipeModes) {
                    const data = recipe(entries, references, arithmetic, createEncoder);
                    const prefix = Buffer.concat([Buffer.from([arithmetic ? 3 : 2]), varint(data.length), data]);
                    const bytes = prefix.length + lower.encoded.length;
                    trials.push({ sourceCeiling: ceiling, level: generation, symbols: sequence.length, entries: entries.length, recipeMode: arithmetic ? 'arithmetic' : 'raw', recipeBytes: prefix.length, dictionaryBytes: lower.encoded.length, totalBytes: bytes });
                    if (bytes < best.encoded.length) best = {
                        encoded: Buffer.concat([prefix, lower.encoded]),
                        layers: [{ level: generation, symbols: sequence.length, entries: entries.length, recipeMode: arithmetic ? 'arithmetic' : 'raw', recipeBytes: prefix.length, dictionaryBits: entries.reduce((sum, node) => sum + node.length, 0), dictionaryBytes: lower.encoded.length }, ...lower.layers],
                        literalBits: lower.literalBits, literalMode: lower.literalMode,
                    };
                }
            }
            if (generation > 0) sequence = lower(sequence, generation - 1);
        }
        memo.set(key, best); return best;
    };
    if (!Number.isSafeInteger(originalLength) || originalLength < 0 || originalLength > root.length || originalLength >= 2 ** 32) throw new Error('Invalid original length');
    let result = compress([root], root.level);
    const hierarchicalBytes = HEADER + result.encoded.length;
    const header = Buffer.alloc(HEADER); header.write('SULO'); header[4] = 1; header[5] = Number(originalLength < root.length);
    const original = flatten(root).slice(0, originalLength);
    const coder = createEncoder(); new Writer(coder).literals(original);
    for (const [mode, payload, literalMode] of [[2, bitsToBytes(original), 'raw'], [3, coder.finish(), 'arithmetic']]) {
        if (payload.length < result.encoded.length) {
            header[5] = mode;
            result = { encoded: payload, layers: [], literalBits: originalLength, literalMode };
        }
    }
    header.writeUInt32BE(originalLength, 6); header.writeUInt32BE(result.encoded.length, 10);
    return { ...result, encoded: Buffer.concat([header, result.encoded]), trials, states: memo.size, recursive, hierarchicalBytes, container: header[5] >= 2 ? 'document' : 'layers' };
}

export function decodeOrdered(buffer, { maxOutputBits = 64 * 1024 * 1024, createDecoder = bytes => new ArithmeticDecoder(bytes) } = {}) {
    if (buffer.length < HEADER || buffer.subarray(0, 4).toString() !== 'SULO' || buffer[4] !== 1 || buffer[5] > 3) throw new Error('Bad ordered-codec frame');
    const originalLength = buffer.readUInt32BE(6), padded = buffer[5] === 1;
    if (originalLength > maxOutputBits || buffer.readUInt32BE(10) !== buffer.length - HEADER) throw new Error('Length limit or truncated frame');
    if (buffer[5] >= 2) {
        const payload = buffer.subarray(HEADER);
        if (buffer[5] === 3) return new Reader(createDecoder(payload)).literals(originalLength);
        if (payload.length !== Math.ceil(originalLength / 8)) throw new Error('Raw document length');
        return bytesToBits(payload).slice(0, originalLength);
    }
    const limit = Math.min(maxOutputBits + 65536, originalLength * 16 + 65536);
    let offset = HEADER;
    const integer = () => {
        let value = 0, factor = 1;
        for (let i = 0; i < 5; i++) {
            if (offset >= buffer.length) throw new Error('Truncated integer');
            const byte = buffer[offset++]; value += (byte & 127) * factor;
            if (value >= 2 ** 32) throw new Error('Integer limit');
            if (byte < 128) return value;
            factor *= 128;
        }
        throw new Error('Integer limit');
    };
    const visit = (depth = 0) => {
        if (depth > 64 || offset >= buffer.length) throw new Error('Invalid nesting');
        const mode = buffer[offset++];
        if (mode < 2) {
            const length = integer(); if (length > limit) throw new Error('Literal limit');
            const payload = buffer.subarray(offset); offset = buffer.length;
            if (mode === 0) {
                if (payload.length !== Math.ceil(length / 8)) throw new Error('Raw literal length');
                return bytesToBits(payload).slice(0, length);
            }
            return new Reader(createDecoder(payload)).literals(length);
        }
        if (mode > 3) throw new Error('Unknown ordered-codec mode');
        const size = integer(); if (size > buffer.length - offset) throw new Error('Truncated recipe');
        const payload = buffer.subarray(offset, offset + size); offset += size;
        const coder = mode === 3 ? createDecoder(payload) : new RawDecoder(payload), reader = new Reader(coder);
        const count = reader.uint(64), entries = reader.uint(128);
        if (!entries || entries >= count || count > limit) throw new Error('Invalid recipe counts');
        const lengths = []; let dictionaryBits = 0;
        for (let i = 0; i < entries; i++) {
            const length = reader.uint(256); if (!length || (dictionaryBits += length) > limit) throw new Error('Dictionary limit');
            lengths.push(length);
        }
        const refs = []; let seen = 0, outputBits = 0;
        for (let i = 0; i < count; i++) {
            const fresh = seen === 0 || (seen < entries && coder.bit(0) === 1);
            const id = fresh ? seen++ : readReference(coder, seen);
            outputBits += lengths[id]; if (outputBits > limit) throw new Error('Expansion limit');
            refs.push(id);
        }
        if (seen !== entries) throw new Error('Unused dictionary entry');
        const content = visit(depth + 1);
        if (content.length !== dictionaryBits) throw new Error('Dictionary length mismatch');
        const dictionary = []; let position = 0;
        for (const length of lengths) { dictionary.push(content.slice(position, position + length)); position += length; }
        return refs.map(id => dictionary[id]).join('');
    };
    const bits = visit();
    if (padded ? !/^10*$/.test(bits.slice(originalLength)) : bits.length !== originalLength) throw new Error('Invalid document length or SUL padding');
    return bits.slice(0, originalLength);
}
