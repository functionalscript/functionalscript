# Brotli static dictionary as SUL level zero

Requires Node.js 24; no npm installation or compiler is needed for normal use.
Run from this extracted directory:

```bash
node --test sul-compression-research/test.mjs sul-ordered-experiment/test.mjs sul-byte-experiment/test.mjs sul-brotli-experiment/test.mjs
node sul-brotli-experiment/benchmark.mjs
node sul-brotli-experiment/cli.mjs compress INPUT OUTPUT.suld full
node sul-brotli-experiment/cli.mjs decompress OUTPUT.suld RESTORED
```

Use base instead of full to omit transforms. The benchmark measures direct,
one-level, and recursive dictionary modes for both profiles on twelve inputs,
checks 72 final outputs and all corresponding dictionary candidates, and checks
twelve byte-SUL controls. Encoded files are regenerated in the results directory.

Known token IDs expand through the pinned shared dictionary; its text is not sent
per document. Fixed-width tokens use 14 bits for base entries or 21 with transforms.
The existing ordered codec and adaptive binary arithmetic model are unchanged.
This produces experimental SULD files, not Brotli files or native SUL root IDs.
Both format headers, token references, escapes, and recipes count in reported sizes.

The MIT-licensed pinned sources are included:
- FunctionalScript d16a9ebf39b30a42e1b795bc329774d867196841
- Google Brotli 09e1ac6c7eea9d3b53f85bcdde6347358dbe1281

The Brotli vendor manifest records dictionary/metadata hashes and the C oracle
stream digest. Tests compare every word/transform combination with that digest.
For independent oracle regeneration, from sul-brotli-experiment:

```bash
cc -O2 -I vendor/brotli/c/include -I vendor/brotli/c/common oracle.c vendor/brotli/c/common/dictionary.c vendor/brotli/c/common/transform.c -o oracle
./oracle > metadata.json
./oracle all > oracle.bin
```

The first output should match vendor/brotli/metadata.json. The binary stream has
19,295,456 bytes and SHA-256
3203c526882031773159512c3dba03abc46ff2dd65cef4875b00b9d22c708b9c.
The report in PR 2047 explains framing, limits, tokenization, shared resource cost,
all comparisons, and the distinction between candidate and selected fallback data:
https://github.com/functionalscript/functionalscript/pull/2047
