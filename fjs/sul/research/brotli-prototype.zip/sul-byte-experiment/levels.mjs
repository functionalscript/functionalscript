// Experimental SUL word hierarchy with raw bit or byte leaves. This deliberately
// bypasses the native bit-specific literal pipeline; it is not a native SUL ID.
import { rawId } from '../sul-compression-research/vendor/fjs/sul/id/module.f.mjs';
import { vec } from '../sul-compression-research/vendor/fjs/types/bit_vec/module.f.mjs';
import { encode, emptyEncodeState } from '../sul-compression-research/vendor/fjs/sul/level/hash/module.f.mjs';
import { flatten } from '../sul-ordered-experiment/levels.mjs';

export function symbolTree(bits, width = 8) {
    if (width !== 1 && width !== 8) throw new Error('Expected complete bit or byte symbols');
    return fixedSymbolTree(bits, width);
}

// Also supports the fixed-width IDs used by the Brotli dictionary experiment.
export function fixedSymbolTree(bits, width) {
    if (!Number.isInteger(width) || width < 1 || width > 24 || bits.length % width || /[^01]/.test(bits)) throw new Error('Expected complete fixed-width symbols');
    const leaves = new Map();
    const leaf = value => {
        if (!leaves.has(value)) leaves.set(value, {
            key: `raw${width}:0:${value}`, value: rawId(vec(BigInt(width))(BigInt(value))),
            level: 0, length: width, bits: value.toString(2).padStart(width, '0'),
        });
        return leaves.get(value);
    };
    const step = encode((_a, _b, _id, _symbol, storage) => storage);
    const levels = [], stats = [];
    const push = leaf => {
        let child = leaf;
        for (let index = 0; ; index++) {
            if (index > 63) throw new Error('Prototype hierarchy depth limit');
            const fresh = index === levels.length;
            if (fresh) {
                levels.push({ state: emptyEncodeState(null), pending: [], interned: new Map() });
                stats.push({ level: index, symbols: 0, ids: new Set() });
            }
            stats[index].symbols++; stats[index].ids.add(child.value);
            const level = levels[index];
            level.pending.push(child);
            const [value, state] = step(child.value, level.state); level.state = state;
            // The first symbol at a new highest level contains the entire
            // stream so far. Only finalization accepts it as the document root.
            if (fresh) return child;
            if (value === undefined) return undefined;
            let node = level.interned.get(value);
            if (!node) {
                node = { key: `raw${width}:${index + 1}:${value}`, value, level: index + 1,
                    length: level.pending.reduce((sum, node) => sum + node.length, 0), children: level.pending };
                level.interned.set(value, node);
            }
            child = node; level.pending = [];
        }
    };
    for (let offset = 0; offset < bits.length; offset += width) push(leaf(parseInt(bits.slice(offset, offset + width), 2)));
    // Both variants append the same bit-level suffix 10*. For bytes the first
    // pad symbol is 0x80, and subsequent pad symbols are 0x00.
    const paddingLimit = Math.max(65536, 4 * bits.length);
    let paddingSymbols = 1, root = push(leaf(2 ** (width - 1)));
    while (root === undefined) {
        if (++paddingSymbols * width > paddingLimit) throw new Error('Prototype finalization limit');
        root = push(leaf(0));
    }
    const padded = bits + '1' + '0'.repeat(paddingSymbols * width - 1);
    if (flatten(root) !== padded) throw new Error('Hierarchy does not reconstruct the input and padding');
    return { root, paddedBits: padded.length, paddingSymbols,
        stats: stats.map(({ level, symbols, ids }) => ({ level, symbols, unique: ids.size })) };
}
