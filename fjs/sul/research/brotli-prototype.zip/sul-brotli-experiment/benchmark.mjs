import fs from 'node:fs';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { gzipSync, gunzipSync, brotliCompressSync, brotliDecompressSync, zstdCompressSync, zstdDecompressSync, constants } from 'node:zlib';
import { fixtures as previousFixtures } from '../sul-ordered-experiment/benchmark.mjs';
import { bytesToBits } from '../sul-compression-research/sul-graph.mjs';
import { symbolTree } from '../sul-byte-experiment/levels.mjs';
import { encodeOrdered, decodeOrdered } from '../sul-ordered-experiment/ordered.mjs';
import { tokenIndex, manifest } from './dictionary.mjs';
import { prepare, encodeDictionary, decodeDictionary } from './codec.mjs';

const prior = JSON.parse(fs.readFileSync(new URL('../sul-byte-experiment/results/results.json', import.meta.url)));
const fixtures = [...previousFixtures,
    ['short_text', Buffer.from('The document contains information about the project. Please contact the development team for additional information and support. All rights reserved.\n'), 'One short English document, designed to exercise preexisting dictionary entries.'],
    ['short_html', Buffer.from('<!DOCTYPE html><html><head><title>Example document</title></head><body><h1>Information</h1><p>Welcome to the website.</p></body></html>\n'), 'One short HTML document with common markup.'],
];
const directory = new URL('./results/', import.meta.url); fs.mkdirSync(directory, { recursive: true });
const report = { version: 4, node: process.version, sulCommit: prior.sulCommit, brotli: manifest,
    tokenizer: 'minimum fixed-width token count; tie longer span then lowest ID',
    leafWidths: { base: 14, full: 21 }, sharedDictionary: 'pinned decoder resource; not sent per file', indexes: {}, fixtures: [] };
for (const [label, transforms] of [['base', false], ['full', true]]) {
    const start = performance.now(), index = tokenIndex(transforms);
    report.indexes[label] = { buildMs: performance.now() - start, distinctMultiByteExpansions: index.map.size, maxLength: index.maxLength };
}
for (const [name, bytes, description] of fixtures) {
    const start = performance.now(), sha256 = createHash('sha256').update(bytes).digest('hex');
    const old = prior.fixtures.find(row => row.name === name);
    if (old) assert.equal(old.sha256, sha256);
    const bits = bytesToBits(bytes), byteStart = performance.now(), { root } = symbolTree(bits, 8);
    const byteResult = encodeOrdered(root, bits.length); assert.equal(decodeOrdered(byteResult.encoded), bits);
    // Recomputing this control also verifies the shared builder generalization.
    if (old) assert.equal(byteResult.encoded.length, old.rawByteRecursive.bytes);
    const row = { name, description, inputBytes: bytes.length, sha256, byteRecursiveBytes: byteResult.encoded.length, byteControlMs: performance.now() - byteStart };
    if (old) {
        row.nativeBitRecursiveBytes = old.nativeBitRecursiveBytes;
        for (const k of ['gzip9Bytes','brotli11Bytes','zstd19Bytes']) row[k] = old[k];
    } else for (const [label, compress, decompress] of [
        ['gzip9', b => gzipSync(b, { level: 9 }), gunzipSync],
        ['brotli11', b => brotliCompressSync(b, { params: { [constants.BROTLI_PARAM_QUALITY]: 11 } }), brotliDecompressSync],
        ['zstd19', b => zstdCompressSync(b, { params: { [constants.ZSTD_c_compressionLevel]: 19 } }), zstdDecompressSync],
    ]) { const encoded = compress(bytes); assert.deepEqual(decompress(encoded), bytes); row[label + 'Bytes'] = encoded.length; }
    for (const [label, transforms] of [['base', false], ['full', true]]) {
        const prepared = prepare(bytes, transforms), { tokens, ...coverage } = prepared.parsed;
        row[label + 'Tree'] = { ...coverage, tokens: tokens.length, tokenBits: prepared.bits.length, tokenizeMs: prepared.tokenizeMs,
            treeMs: prepared.treeMs, paddedBits: prepared.tree.paddedBits, levels: prepared.tree.stats };
        for (const kind of ['direct','flat','recursive']) {
            const start = performance.now(), result = encodeDictionary(bytes, { transforms, kind, prepared });
            const encodeMs = performance.now() - start, decodeStart = performance.now();
            assert.deepEqual(decodeDictionary(result.encoded), bytes);
            // Verify dictionary candidates even when the document fallback wins.
            assert.deepEqual(decodeDictionary(result.candidate), bytes);
            const key = label + kind[0].toUpperCase() + kind.slice(1), r = result.result;
            row[key] = { bytes: result.encoded.length, candidateBytes: result.candidateBytes, selected: result.selected, encodeMs,
                decodeMs: performance.now() - decodeStart, candidateLayers: r.layers, candidateLiteralBits: r.literalBits, candidateLiteralMode: r.literalMode, states: r.states, trials: r.trials };
            fs.writeFileSync(new URL(`${name}-${key}.suld`, directory), result.encoded);
        }
    }
    row.totalMs = performance.now() - start; report.fixtures.push(row);
    fs.writeFileSync(new URL('results.json', directory), JSON.stringify(report, null, 2) + '\n');
    console.log(JSON.stringify({ name, input: bytes.length, byte: row.byteRecursiveBytes, base: row.baseRecursive.bytes, full: row.fullRecursive.bytes,
        baseDirect: row.baseDirect.bytes, fullDirect: row.fullDirect.bytes, fullFlat: row.fullFlat.bytes,
        coverage: +(row.fullTree.dictionaryBytes / bytes.length).toFixed(3), seconds: +(row.totalMs / 1000).toFixed(2) }));
}
const fields = ['name','inputBytes','byteRecursiveBytes','baseDirectBytes','baseFlatBytes','baseRecursiveBytes','fullDirectBytes','fullFlatBytes','fullRecursiveBytes','gzip9Bytes','brotli11Bytes','zstd19Bytes'];
const rows = report.fixtures.map(row => ({ ...row, ...Object.fromEntries(['base','full'].flatMap(label => ['Direct','Flat','Recursive'].map(kind => [label + kind + 'Bytes', row[label + kind].bytes]))) }));
fs.writeFileSync(new URL('summary.csv', directory), fields.join(',') + '\n' + rows.map(row => fields.map(key => row[key]).join(',')).join('\n') + '\n');
console.log('All 72 final encodings, 72 dictionary candidates, and 12 byte controls decoded exactly; all 10 prior hashes and byte-control sizes matched.');
