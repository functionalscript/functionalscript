import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { words, transformCount, transform, tokenize, tokensToBits, restore, expand, manifest } from './dictionary.mjs';
import { prepare, encodeDictionary, decodeDictionary } from './codec.mjs';
import { fixtures } from '../sul-ordered-experiment/benchmark.mjs';

test('all 1,633,984 base-word/transform combinations match the pinned C oracle', () => {
    assert.equal(words.length, 13504); assert.equal(transformCount, 121);
    const hash = createHash('sha256'); let bytes = 0;
    for (let tr = 0; tr < transformCount; tr++) for (let index = 0; index < words.length; index++) {
        const word = transform(index, tr); hash.update(Buffer.from([word.length])); hash.update(word); bytes += 1 + word.length;
    }
    assert.equal(bytes, manifest.oracleStreamBytes);
    assert.equal(hash.digest('hex'), manifest.oracleSha256);
});

test('base words, transformed forms, and arbitrary byte content tokenize losslessly', () => {
    const inputs = [Buffer.alloc(0), Buffer.from(Array.from({ length: 256 }, (_, i) => i)), Buffer.from('Time TIME time, the document contains information.\n'), Buffer.from('Привет 世界 café\0\xff', 'utf8')];
    for (const transforms of [false, true]) for (const bytes of inputs) {
        const parsed = tokenize(bytes, transforms);
        assert.deepEqual(restore(tokensToBits(parsed.tokens, transforms), transforms), bytes);
    }
    assert.deepEqual(expand(256, false), Buffer.from('time'));
    assert.equal(tokenize(Buffer.from('time'), false).tokens.length, 1);
    assert.ok(tokenize(Buffer.from('TIME '), true).transformedTokens > 0);
});

test('direct, flat, and recursive dictionary frames and their candidates decode exactly', () => {
    for (const bytes of [Buffer.alloc(0), Buffer.from([0,255,128]), Buffer.from('The immutable document shares a repeated sentence.\n'.repeat(128))]) {
        for (const transforms of [false, true]) {
            const prepared = prepare(bytes, transforms);
            const sizes = [];
            for (const kind of ['direct','flat','recursive']) {
                const result = encodeDictionary(bytes, { transforms, kind, prepared });
                assert.deepEqual(decodeDictionary(result.encoded), bytes);
                assert.deepEqual(decodeDictionary(result.candidate), bytes);
                assert.ok(result.encoded.length <= bytes.length + 14);
                sizes.push(result.encoded.length);
            }
            assert.ok(sizes[2] <= sizes[1]);
        }
    }
});

test('malformed references, partial tokens, frames, and expansion limits are refused', () => {
    assert.throws(() => expand(256 + words.length, false));
    assert.throws(() => expand(-1));
    assert.throws(() => restore('1'));
    assert.throws(() => restore(tokensToBits([256]), true, 3));
    const result = encodeDictionary(Buffer.from('time time time'));
    assert.throws(() => decodeDictionary(result.encoded.subarray(0, -1)));
    assert.throws(() => decodeDictionary(result.encoded, { maxOutputBytes: 1 }));
    const bad = Buffer.from(result.encoded); bad[4] = 2;
    assert.throws(() => decodeDictionary(bad));
});

test('intermediate token padding may exceed the original token-count budget', () => {
    const bytes = fixtures.find(([name]) => name === 'repeated_random_block')[1];
    const prepared = prepare(bytes, false);
    assert.ok(prepared.tree.paddedBits > bytes.length * 14 + 65536);
    const result = encodeDictionary(bytes, { transforms: false, prepared });
    assert.deepEqual(decodeDictionary(result.candidate), bytes);
});
