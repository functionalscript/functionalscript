import fs from 'node:fs';
import { createHash } from 'node:crypto';

export const manifest = JSON.parse(fs.readFileSync(new URL('./vendor/brotli/manifest.json', import.meta.url)));
const data = fs.readFileSync(new URL('./vendor/brotli/c/common/dictionary.bin', import.meta.url));
const metadata = fs.readFileSync(new URL('./vendor/brotli/metadata.json', import.meta.url));
const sha = data => createHash('sha256').update(data).digest('hex');
if (sha(data) !== manifest.dictionarySha256 || sha(metadata) !== manifest.metadataSha256) throw new Error('Static dictionary snapshot mismatch');
const table = JSON.parse(metadata);
const affixes = table.affixes.map(hex => Buffer.from(hex, 'hex'));
export const words = [];
for (let length = 4; length <= 24; length++) for (let index = 0; index < 2 ** table.sizeBits[length]; index++) {
    const offset = table.offsets[length] + index * length;
    words.push(data.subarray(offset, offset + length));
}
export const transformCount = table.transforms.length;

// Brotli's byte operations, including its specified non-Unicode casing rule.
function upper(bytes, offset) {
    if (bytes[offset] < 0xc0) {
        if (bytes[offset] >= 97 && bytes[offset] <= 122) bytes[offset] ^= 32;
        return 1;
    }
    if (bytes[offset] < 0xe0) { bytes[offset + 1] ^= 32; return 2; }
    bytes[offset + 2] ^= 5; return 3;
}
export function transform(wordIndex, transformIndex = 0) {
    if (!Number.isInteger(wordIndex) || !words[wordIndex] || !Number.isInteger(transformIndex) || !table.transforms[transformIndex]) throw new Error('Invalid static dictionary reference');
    const [prefix, type, suffix] = table.transforms[transformIndex];
    let word = words[wordIndex];
    if (type <= 9) word = word.subarray(0, Math.max(0, word.length - type));
    else if (type >= 12 && type <= 20) word = word.subarray(Math.min(word.length, type - 11));
    else if (type === 10 || type === 11) {
        word = Buffer.from(word);
        if (type === 10) upper(word, 0);
        else for (let offset = 0; offset < word.length;) offset += upper(word, offset);
    } else throw new Error('Unsupported transform');
    return Buffer.concat([affixes[prefix], word, affixes[suffix]]);
}

// Fixed IDs: 0..255 are literal bytes; dictionary IDs are transform-major.
// Base-word order follows the official length buckets and their entry order.
export const tokenWidth = transforms => transforms ? 21 : 14;
export function expand(id, transforms = true) {
    const limit = 256 + words.length * (transforms ? transformCount : 1);
    if (!Number.isInteger(id) || id < 0 || id >= limit) throw new Error('Invalid token ID');
    if (id < 256) return Buffer.from([id]);
    return transform((id - 256) % words.length, Math.floor((id - 256) / words.length));
}

const caches = new Map();
export function tokenIndex(transforms = true) {
    if (caches.has(transforms)) return caches.get(transforms);
    const map = new Map(); let maxLength = 1;
    for (let tr = 0; tr < (transforms ? transformCount : 1); tr++) for (let index = 0; index < words.length; index++) {
        const word = transform(index, tr);
        // Empty forms cannot advance a parse; one-byte aliases use literal IDs.
        if (word.length < 2) continue;
        const text = word.toString('latin1');
        if (!map.has(text)) map.set(text, 256 + tr * words.length + index);
        maxLength = Math.max(maxLength, word.length);
    }
    const result = { map, maxLength }; caches.set(transforms, result); return result;
}

// Minimum token count for fixed-width token IDs. Ties prefer longer matches,
// then the smallest ID for the same expansion. This is not an optimizer for
// the eventual adaptive arithmetic / hierarchical compressed size.
export function tokenize(bytes, transforms = true) {
    const { map, maxLength } = tokenIndex(transforms), text = bytes.toString('latin1');
    const costs = new Uint32Array(bytes.length + 1), ids = new Uint32Array(bytes.length), spans = new Uint8Array(bytes.length);
    for (let offset = bytes.length - 1; offset >= 0; offset--) {
        costs[offset] = 1 + costs[offset + 1]; ids[offset] = bytes[offset]; spans[offset] = 1;
        for (let size = 2; size <= Math.min(maxLength, bytes.length - offset); size++) {
            const id = map.get(text.slice(offset, offset + size));
            if (id !== undefined && 1 + costs[offset + size] <= costs[offset]) {
                costs[offset] = 1 + costs[offset + size]; ids[offset] = id; spans[offset] = size;
            }
        }
    }
    const tokens = []; let dictionaryBytes = 0, dictionaryTokens = 0, transformedTokens = 0;
    for (let offset = 0; offset < bytes.length; offset += spans[offset]) {
        const id = ids[offset]; tokens.push(id);
        if (id >= 256) { dictionaryTokens++; dictionaryBytes += spans[offset]; }
        if (id >= 256 + words.length) transformedTokens++;
    }
    return { tokens, dictionaryBytes, dictionaryTokens, transformedTokens, literalTokens: tokens.length - dictionaryTokens };
}

export const tokensToBits = (tokens, transforms = true) => tokens.map(id => id.toString(2).padStart(tokenWidth(transforms), '0')).join('');
export function restore(bits, transforms = true, maxBytes = 8 * 1024 * 1024) {
    const width = tokenWidth(transforms);
    if (bits.length % width) throw new Error('Incomplete token');
    const chunks = []; let length = 0;
    for (let offset = 0; offset < bits.length; offset += width) {
        const chunk = expand(parseInt(bits.slice(offset, offset + width), 2), transforms);
        if (!chunk.length || (length += chunk.length) > maxBytes) throw new Error('Invalid or excessive token expansion');
        chunks.push(chunk);
    }
    return Buffer.concat(chunks, length);
}
