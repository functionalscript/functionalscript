import { ArithmeticEncoder, ArithmeticDecoder, Writer, Reader } from '../sul-compression-research/arithmetic.mjs';
import { bytesToBits, bitsToBytes } from '../sul-compression-research/sul-graph.mjs';
import { fixedSymbolTree } from '../sul-byte-experiment/levels.mjs';
import { encodeOrdered, decodeOrdered } from '../sul-ordered-experiment/ordered.mjs';
import { tokenize, tokenWidth, tokensToBits, restore } from './dictionary.mjs';

const HEADER = 14;
function frame(mode, payload, originalBytes) {
    const header = Buffer.alloc(HEADER); header.write('SULD'); header[4] = 1; header[5] = mode;
    header.writeUInt32BE(originalBytes, 6); header.writeUInt32BE(payload.length, 10);
    return Buffer.concat([header, payload]);
}

export function prepare(bytes, transforms = true) {
    const start = performance.now(), parsed = tokenize(bytes, transforms);
    const bits = tokensToBits(parsed.tokens, transforms), tokenizeMs = performance.now() - start;
    const treeStart = performance.now(), tree = fixedSymbolTree(bits, tokenWidth(transforms));
    return { parsed, bits, tree, tokenizeMs, treeMs: performance.now() - treeStart };
}

export function encodeDictionary(bytes, { transforms = true, kind = 'recursive', prepared = prepare(bytes, transforms) } = {}) {
    if (!['direct','flat','recursive'].includes(kind)) throw new Error('Unknown experiment mode');
    const { bits, tree } = prepared;
    const root = kind === 'direct' ? { key: 'direct', level: 0, length: bits.length, bits } : tree.root;
    const result = encodeOrdered(root, bits.length, { recursive: kind === 'recursive' });
    const candidate = frame(transforms ? 3 : 2, result.encoded, bytes.length);
    const coder = new ArithmeticEncoder(); new Writer(coder).literals(bytesToBits(bytes));
    let encoded = candidate, selected = 'dictionary';
    for (const [mode, payload, label] of [[0, bytes, 'raw'], [1, coder.finish(), 'arithmetic']]) {
        const fallback = frame(mode, payload, bytes.length);
        if (fallback.length < encoded.length) { encoded = fallback; selected = label; }
    }
    return { encoded, candidate, candidateBytes: candidate.length, selected, result };
}

export function decodeDictionary(buffer, { maxOutputBytes = 8 * 1024 * 1024 } = {}) {
    if (buffer.length < HEADER || buffer.subarray(0, 4).toString() !== 'SULD' || buffer[4] !== 1 || buffer[5] > 3) throw new Error('Bad dictionary frame');
    const length = buffer.readUInt32BE(6), payload = buffer.subarray(HEADER), mode = buffer[5];
    if (length > maxOutputBytes || buffer.readUInt32BE(10) !== payload.length) throw new Error('Frame length or output limit');
    let decoded;
    if (mode === 0) decoded = payload;
    else if (mode === 1) decoded = bitsToBytes(new Reader(new ArithmeticDecoder(payload)).literals(length * 8));
    else {
        // At most one token per input byte for valid streams; this also caps
        // intermediate expansion before converting IDs into dictionary strings.
        const tokenLimit = length * tokenWidth(mode === 3);
        // The builder can append up to max(65536, 4 * tokenBits) padding
        // bits. Allow that intermediate expansion, then bound unpadded IDs.
        const tokenBits = decodeOrdered(payload, { maxOutputBits: 5 * tokenLimit + 65536 });
        if (tokenBits.length > tokenLimit) throw new Error('Excessive token count');
        decoded = restore(tokenBits, mode === 3, length);
    }
    if (decoded.length !== length) throw new Error('Decoded document length mismatch');
    return decoded;
}
