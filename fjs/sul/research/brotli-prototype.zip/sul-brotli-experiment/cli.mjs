import fs from 'node:fs';
import assert from 'node:assert/strict';
import { encodeDictionary, decodeDictionary } from './codec.mjs';

const [command, input, output, profile = 'full'] = process.argv.slice(2);
if (!input || !output || !['compress','decompress'].includes(command) || !['base','full'].includes(profile)) throw new Error('Usage: node cli.mjs compress|decompress INPUT OUTPUT [base|full]');
const bytes = fs.readFileSync(input);
if (command === 'compress') {
    const result = encodeDictionary(bytes, { transforms: profile === 'full' });
    assert.deepEqual(decodeDictionary(result.encoded), bytes);
    fs.writeFileSync(output, result.encoded);
    console.log(JSON.stringify({ inputBytes: bytes.length, outputBytes: result.encoded.length, profile, selected: result.selected, candidateBytes: result.candidateBytes }));
} else fs.writeFileSync(output, decodeDictionary(bytes));
