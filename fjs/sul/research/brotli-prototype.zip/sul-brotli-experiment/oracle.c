/* Research extraction/verification helper, linked to the pinned MIT Brotli source. */
#include <stdio.h>
#include "dictionary.h"
#include "transform.h"

int main(int argc, char** argv) {
    const BrotliDictionary* d = BrotliGetDictionary();
    const BrotliTransforms* t = BrotliGetTransforms();
    (void)argv;
    if (argc > 1) {
        /* Exhaustive oracle stream: one byte of length, then transformed bytes,
           in transform-major, word-length-major, dictionary-index order. */
        unsigned tr, len, index;
        unsigned char out[256];
        for (tr = 0; tr < t->num_transforms; tr++) for (len = 4; len <= 24; len++) {
            for (index = 0; index < (1u << d->size_bits_by_length[len]); index++) {
                int n = BrotliTransformDictionaryWord(out, d->data + d->offsets_by_length[len] + index * len, len, t, tr);
                if (n < 0 || n > 255) return 2;
                putchar(n); fwrite(out, 1, n, stdout);
            }
        }
        return ferror(stdout) ? 1 : 0;
    }
    printf("{\"sizeBits\":[");
    for (int i = 0; i < 32; i++) printf("%s%u", i ? "," : "", d->size_bits_by_length[i]);
    printf("],\"offsets\":[");
    for (int i = 0; i < 32; i++) printf("%s%u", i ? "," : "", d->offsets_by_length[i]);
    printf("],\"affixes\":[");
    for (int i = 0; i < 50; i++) {
        const unsigned char* p = t->prefix_suffix + t->prefix_suffix_map[i];
        printf("%s\"", i ? "," : "");
        for (int j = 1; j <= p[0]; j++) printf("%02x", p[j]);
        printf("\"");
    }
    printf("],\"transforms\":[");
    for (unsigned i = 0; i < t->num_transforms; i++) printf("%s[%u,%u,%u]", i ? "," : "", t->transforms[3*i], t->transforms[3*i+1], t->transforms[3*i+2]);
    printf("]}\n");
    return 0;
}
