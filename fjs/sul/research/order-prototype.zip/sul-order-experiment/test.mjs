import test from 'node:test';
import assert from 'node:assert/strict';
import { naturalOrder, rankOf, countGroups, measureGroups, optimizeByteOrder } from './order.mjs';
import { encodeWithOrder, decodeBytes } from './codec.mjs';
import { fixedSymbolTree } from '../sul-byte-experiment/levels.mjs';
import { bytesToBits } from '../sul-compression-research/sul-graph.mjs';
import { flatten } from '../sul-ordered-experiment/levels.mjs';

test('full byte permutations are validated', () => {
    assert.equal(new Set(rankOf(naturalOrder())).size, 256);
    for (const bad of [[0], Array(256).fill(0), [...naturalOrder().slice(0,255),256]]) assert.throws(() => rankOf(bad));
    assert.throws(() => fixedSymbolTree('0', 1, { byteOrder: naturalOrder() }));
});

test('group-count scan agrees with an independent streaming stopping-rule oracle', () => {
    const permutations = [[0,1,2],[0,2,1],[1,0,2],[1,2,0],[2,0,1],[2,1,0]];
    for (const first of permutations) {
        const rank = rankOf([...first, ...naturalOrder().slice(3)]);
        for (let length = 0; length <= 6; length++) for (let value = 0; value < 3 ** length; value++) {
            let n = value; const bytes = Buffer.alloc(length);
            for (let i = 0; i < length; i++) { bytes[i] = n % 3; n = Math.floor(n / 3); }
            let last, groups = 0;
            for (const byte of bytes) { const next = rank[byte]; if (last === undefined) last = next; else if (next < last) last = next; else { groups++; last = undefined; } }
            if (last !== undefined) groups++;
            assert.equal(countGroups(bytes, rank), groups);
        }
    }
});

test('natural comparison keys preserve the existing byte hierarchy and root', () => {
    for (const bytes of [Buffer.alloc(0), Buffer.from([255]), Buffer.from(naturalOrder()), Buffer.from('SUL orders bytes, but preserves their payload.\n'.repeat(4))]) {
        const bits = bytesToBits(bytes), a = fixedSymbolTree(bits,8), b = fixedSymbolTree(bits,8,{byteOrder:naturalOrder()});
        assert.equal(a.root.value,b.root.value); assert.equal(a.paddedBits,b.paddedBits); assert.deepEqual(a.stats,b.stats); assert.equal(flatten(a.root),flatten(b.root));
    }
});

test('a reversed order can keep a 256-byte ascending prefix in one completed word', () => {
    const bytes = Buffer.from([...naturalOrder(),255]), order = naturalOrder().reverse();
    assert.equal(measureGroups(bytes,order).groups,1); assert.equal(measureGroups(bytes,order).longest,257);
    const result = encodeWithOrder(bytes,order); assert.deepEqual(decodeBytes(result.encoded),bytes);
    assert.equal(flatten(result.tree.root).slice(0,bytes.length*8),bytesToBits(bytes));
});

test('the decoder restores original bytes without knowing the optimized order', () => {
    const bytes = Buffer.concat([Buffer.from('λ FunctionalScript 🙂\n'.repeat(12)),Buffer.from(naturalOrder())]);
    const search = optimizeByteOrder(bytes,{proposals:64,restarts:2});
    const result = encodeWithOrder(bytes,search.order); assert.deepEqual(decodeBytes(result.encoded),bytes);
    let count = 0;
    const visit = (node, offset) => { if(offset>=bytes.length*8)return; if(node.level===1){count++;return;} for(const child of node.children??[]){visit(child,offset);offset+=child.length;} };
    visit(result.tree.root,0); assert.equal(count,search.groups);
});

test('search is deterministic and retains the natural-order group-count bound', () => {
    for(const bytes of [Buffer.alloc(0),Buffer.alloc(63,5),Buffer.from('ABCD '.repeat(30)),Buffer.from(naturalOrder())]) {
        const a = optimizeByteOrder(bytes,{proposals:64,restarts:2}), b = optimizeByteOrder(bytes,{proposals:64,restarts:2});
        assert.deepEqual(a.order,b.order); assert.equal(a.groups,b.groups); assert.ok(a.groups<=a.baselineGroups); assert.equal(measureGroups(bytes,a.order).groups,a.groups);
    }
});
