import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { naturalOrder, measureGroups } from './order.mjs';

const results=JSON.parse(fs.readFileSync(new URL('./results/results.json',import.meta.url)));
const randomBytes=(length,initial)=>{let seed=initial;const out=Buffer.alloc(length);for(let i=0;i<length;i++){seed^=seed<<13;seed^=seed>>>17;seed^=seed<<5;out[i]=(seed>>>0)&255;}return out;};
const walk=dir=>fs.readdirSync(dir,{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name,'en')).flatMap(e=>e.isDirectory()?walk(path.join(dir,e.name)):[path.join(dir,e.name)]);
const vendor=fileURLToPath(new URL('../sul-compression-research/vendor/',import.meta.url));
const source=Buffer.concat(walk(vendor).filter(p=>p.endsWith('.mjs')).map(p=>fs.readFileSync(p)));
assert.ok(source.length>65536);
const cases=[['source_code',source.subarray(65536,131072),'Next available source bytes after the 64 KiB fitting sample; not used by order search.'],
    ['uniform_random',randomBytes(65536,0x81ac339b),'Independent xorshift32 stream, seed 0x81ac339b; not used by order search.']];
const rows=cases.map(([name,bytes,description])=>{const order=results.fixtures.find(r=>r.name===name).search.order;return {name,description,inputBytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex'),natural:measureGroups(bytes,naturalOrder()),fittedOrder:measureGroups(bytes,order)};});
fs.writeFileSync(new URL('./results/heldout.json',import.meta.url),JSON.stringify(rows,null,2)+'\n');
console.log(JSON.stringify(rows.map(r=>({name:r.name,bytes:r.inputBytes,naturalGroups:r.natural.groups,fittedGroups:r.fittedOrder.groups,naturalMean:r.natural.meanLength,fittedMean:r.fittedOrder.meanLength})),null,2));
