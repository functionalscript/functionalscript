import fs from 'node:fs';
import { optimizeByteOrder } from './order.mjs';
import { encodeWithOrder, decodeBytes } from './codec.mjs';

const [command,input,output] = process.argv.slice(2);
if(!input||!['order','encode','decode'].includes(command)||command!=='order'&&!output) throw new Error('Usage: node cli.mjs order INPUT | encode INPUT OUTPUT | decode INPUT OUTPUT');
const bytes=fs.readFileSync(input);
if(command==='decode')fs.writeFileSync(output,decodeBytes(bytes));
else {
    const search=optimizeByteOrder(bytes);
    if(command==='order')console.log(JSON.stringify(search,null,2));
    else {const result=encodeWithOrder(bytes,search.order);fs.writeFileSync(output,result.encoded);console.log(JSON.stringify({bytes:result.encoded.length,groups:search.groups,order:search.order}));}
}
