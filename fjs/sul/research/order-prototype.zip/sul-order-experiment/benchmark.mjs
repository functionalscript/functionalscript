import fs from 'node:fs';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { fixtures } from '../sul-ordered-experiment/benchmark.mjs';
import { naturalOrder, measureGroups, optimizeByteOrder } from './order.mjs';
import { encodeWithOrder, decodeBytes } from './codec.mjs';

const prior = JSON.parse(fs.readFileSync(new URL('../sul-byte-experiment/results/results.json',import.meta.url)));
const directory = new URL('./results/',import.meta.url); fs.mkdirSync(directory,{recursive:true});
const selected = process.argv.slice(2), inputs = selected.length ? fixtures.filter(([name])=>selected.includes(name)) : fixtures;
const report = {version:1,node:process.version,sulCommit:prior.sulCommit,scope:'Optimize only the comparison order of byte symbols at level zero, independently per input. Higher levels retain numeric SUL-ID ordering.',
    objective:'Minimum full-input level-one group occurrences; final incomplete word counted once. No compression size is used during order search.',
    orderDirection:'ascending rank: order[0] is lowest; order[255] is highest',
    search:{seed:0x53554c31,proposals:2048,restarts:3,description:'Eight initial orders plus transition insertion search, followed by bounded simulated annealing on exact group count and up to three adjacent-swap sweeps.'},
    format:'Unchanged SULO v1. Original byte payloads and explicit reconstruction recipes make the order unnecessary to decode; no uncounted shared resource.',fixtures:[]};
for(const [name,bytes,description] of inputs) {
    const start = performance.now(), previous = prior.fixtures.find(x=>x.name===name), sha256=createHash('sha256').update(bytes).digest('hex'); assert.equal(sha256,previous.sha256);
    const search=optimizeByteOrder(bytes,report.search), originalGroups=measureGroups(bytes,naturalOrder()), optimizedGroups=measureGroups(bytes,search.order);
    console.log(JSON.stringify({phase:'search',name,originalGroups:originalGroups.groups,optimizedGroups:optimizedGroups.groups,meanBefore:originalGroups.meanLength,meanAfter:optimizedGroups.meanLength,seconds:+(search.searchMs/1000).toFixed(2)}));
    const row={name,description,inputBytes:bytes.length,sha256,originalGroups,optimizedGroups,search,baselineBytes:previous.rawByteRecursive.bytes,brotli11Bytes:previous.brotli11Bytes,zstd19Bytes:previous.zstd19Bytes};
    for(const [label,order] of [['natural',naturalOrder()],['optimized',search.order]]) {
        const result=encodeWithOrder(bytes,order), beforeDecode=performance.now(); assert.deepEqual(decodeBytes(result.encoded),bytes);
        const decodeMs=performance.now()-beforeDecode;
        if(label==='natural') {
            assert.equal(result.encoded.length,previous.rawByteRecursive.bytes);
            assert.deepEqual(result.encoded,fs.readFileSync(new URL(`../sul-byte-experiment/results/${name}-rawByteRecursive.sulo`,import.meta.url)));
        }
        let actualGroups=0;
        const visit=(node,offset)=>{if(offset>=bytes.length*8)return;if(node.level===1){actualGroups++;return;}for(const child of node.children??[]){visit(child,offset);offset+=child.length;}};visit(result.tree.root,0);
        assert.equal(actualGroups,label==='natural'?originalGroups.groups:optimizedGroups.groups);
        row[label]={bytes:result.encoded.length,hierarchicalBytes:result.hierarchicalBytes,container:result.container,layers:result.layers,literalBits:result.literalBits,literalMode:result.literalMode,
            treeMs:result.treeMs,encodeMs:result.encodeMs,decodeMs,paddedBits:result.tree.paddedBits,paddingSymbols:result.tree.paddingSymbols,levels:result.tree.stats,states:result.states,trials:result.trials};
        fs.writeFileSync(new URL(`${name}-${label}.sulo`,directory),result.encoded);
    }
    row.groupReduction=1-optimizedGroups.groups/originalGroups.groups;row.compressionReduction=1-row.optimized.bytes/row.natural.bytes;row.bestOfTwoBytes=Math.min(row.natural.bytes,row.optimized.bytes);row.totalMs=performance.now()-start;report.fixtures.push(row);
    fs.writeFileSync(new URL('results.json',directory),JSON.stringify(report,null,2)+'\n');
    console.log(JSON.stringify({phase:'compression',name,natural:row.natural.bytes,optimized:row.optimized.bytes,brotli:row.brotli11Bytes,seconds:+(row.totalMs/1000).toFixed(2)}));
}
const fields=['name','inputBytes','naturalGroups','optimizedGroups','naturalMeanLength','optimizedMeanLength','groupReduction','naturalBytes','optimizedBytes','compressionReduction','bestOfTwoBytes','brotli11Bytes','zstd19Bytes','searchMs'];
const rows=report.fixtures.map(r=>({...r,naturalGroups:r.originalGroups.groups,optimizedGroups:r.optimizedGroups.groups,naturalMeanLength:r.originalGroups.meanLength,optimizedMeanLength:r.optimizedGroups.meanLength,naturalBytes:r.natural.bytes,optimizedBytes:r.optimized.bytes,searchMs:r.search.searchMs}));
fs.writeFileSync(new URL('summary.csv',directory),fields.join(',')+'\n'+rows.map(row=>fields.map(k=>row[k]).join(',')).join('\n')+'\n');
console.log(`All ${inputs.length*2} files decoded exactly; all ${inputs.length} natural controls reproduced previous compressed files byte for byte.`);
