import { bytesToBits, bitsToBytes } from '../sul-compression-research/sul-graph.mjs';
import { fixedSymbolTree } from '../sul-byte-experiment/levels.mjs';
import { encodeOrdered, decodeOrdered } from '../sul-ordered-experiment/ordered.mjs';
import { naturalOrder, optimizeByteOrder } from './order.mjs';

export function encodeWithOrder(bytes, order = naturalOrder()) {
    const bits = bytesToBits(bytes), start = performance.now();
    const tree = fixedSymbolTree(bits, 8, { byteOrder: order }), treeMs = performance.now() - start;
    const encodeStart = performance.now(), result = encodeOrdered(tree.root, bits.length);
    return { tree, treeMs, encodeMs: performance.now() - encodeStart, ...result };
}

export function encodeOptimized(bytes, options) {
    const search = optimizeByteOrder(bytes, options);
    return { search, ...encodeWithOrder(bytes, search.order) };
}

export function decodeBytes(encoded) { return bitsToBytes(decodeOrdered(encoded)); }
