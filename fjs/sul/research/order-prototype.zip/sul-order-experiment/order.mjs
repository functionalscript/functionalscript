// Research search over the comparison order of the 256 byte symbols.
// Orders list byte values from lowest to highest rank. Search is deterministic.
export const naturalOrder = () => Array.from({ length: 256 }, (_, i) => i);

export function rankOf(order) {
    if (order.length !== 256 || new Set(order).size !== 256 || order.some(x => !Number.isInteger(x) || x < 0 || x > 255)) throw new Error('Expected a byte permutation');
    const rank = new Uint16Array(256);
    order.forEach((byte, i) => { rank[byte] = i; });
    return rank;
}

// The final incomplete word counts as one group. This equals the number of
// level-one occurrences intersecting real input, before the padding suffix.
export function countGroups(bytes, rank) {
    let groups = 0;
    for (let i = 0; i < bytes.length; groups++) {
        let j = i + 1;
        while (j < bytes.length && rank[bytes[j - 1]] > rank[bytes[j]]) j++;
        i = Math.min(j + 1, bytes.length);
    }
    return groups;
}

export function measureGroups(bytes, order) {
    const rank = rankOf(order), unique = new Set(), histogram = {};
    let groups = 0, complete = 0, longest = 0, pendingBytes = 0;
    for (let i = 0; i < bytes.length; groups++) {
        let j = i + 1;
        while (j < bytes.length && rank[bytes[j - 1]] > rank[bytes[j]]) j++;
        const end = Math.min(j + 1, bytes.length), length = end - i;
        if (j < bytes.length) complete++; else pendingBytes = length;
        unique.add(Buffer.from(bytes.subarray(i, end)).toString('hex'));
        histogram[length] = (histogram[length] ?? 0) + 1;
        longest = Math.max(longest, length); i = end;
    }
    return { groups, complete, pendingBytes, unique: unique.size, meanLength: groups ? bytes.length / groups : 0, longest, histogram };
}

function random(seed) {
    let state = seed >>> 0;
    return () => { state ^= state << 13; state ^= state >>> 17; state ^= state << 5; return (state >>> 0) / 0x100000000; };
}

function transitionScore(order, matrix) {
    let result = 0;
    for (let i = 1; i < order.length; i++) for (let j = 0; j < i; j++) result += matrix[order[i] * 256 + order[j]];
    return result;
}

// Strict-improvement insertion search for the pairwise descending-edge proxy.
function improveTransitions(initial, matrix, active, maxSweeps = 12) {
    const order = [...initial];
    for (let sweep = 0; sweep < maxSweeps; sweep++) {
        let moved = false;
        for (const a of active) {
            const from = order.indexOf(a); let best = from, bestDelta = 0, delta = 0;
            for (let to = from + 1; to < order.length; to++) {
                const b = order[to]; delta += matrix[a * 256 + b] - matrix[b * 256 + a];
                if (delta > bestDelta) { bestDelta = delta; best = to; }
            }
            delta = 0;
            for (let to = from - 1; to >= 0; to--) {
                const b = order[to]; delta += matrix[b * 256 + a] - matrix[a * 256 + b];
                if (delta > bestDelta) { bestDelta = delta; best = to; }
            }
            if (best !== from) { order.splice(from, 1); order.splice(best, 0, a); moved = true; }
        }
        if (!moved) break;
    }
    return order;
}

export function optimizeByteOrder(bytes, { seed = 0x53554c31, proposals = 2048, restarts = 3 } = {}) {
    if (!Number.isInteger(proposals) || proposals < 0 || !Number.isInteger(restarts) || restarts < 1) throw new Error('Invalid search budget');
    const start = performance.now(), rng = random(seed), frequency = new Uint32Array(256), matrix = new Uint32Array(256 * 256);
    for (let i = 0; i < bytes.length; i++) { frequency[bytes[i]]++; if (i) matrix[bytes[i - 1] * 256 + bytes[i]]++; }
    const natural = naturalOrder(), active = natural.filter(x => frequency[x]), absent = natural.filter(x => !frequency[x]);
    const first = [...new Set(bytes)], byFrequency = [...active].sort((a, b) => frequency[b] - frequency[a] || a - b);
    const seeds = [natural, [...natural].reverse(), [...first, ...absent], [...byFrequency, ...absent], [...byFrequency].reverse().concat(absent)];
    for (let n = 0; n < 3; n++) { const shuffled = [...active]; for (let i = shuffled.length - 1; i > 0; i--) { const j = Math.floor(rng() * (i + 1)); [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]]; } seeds.push([...shuffled, ...absent]); }
    let evaluations = 0, bestOrder = natural, bestCount = countGroups(bytes, rankOf(natural));
    const improvements = [], candidates = [], seen = new Set();
    const evaluate = (order, stage) => {
        const groups = countGroups(bytes, rankOf(order)); evaluations++;
        if (groups < bestCount) { bestCount = groups; bestOrder = [...order]; improvements.push({ stage, evaluation: evaluations, groups }); }
        return groups;
    };
    for (const [index, initial] of seeds.entries()) for (const [stage, order] of [['seed', initial], ['transition', improveTransitions(initial, matrix, active)]]) {
        const key = order.join(','); if (seen.has(key)) continue; seen.add(key);
        candidates.push({ order, groups: evaluate(order, `${stage}-${index}`), proxyScore: transitionScore(order, matrix) });
    }
    candidates.sort((a, b) => a.groups - b.groups);
    if (active.length > 1) for (let restart = 0; restart < Math.min(restarts, candidates.length); restart++) {
        let current = [...candidates[restart].order], currentCount = candidates[restart].groups;
        for (let iteration = 0; iteration < proposals; iteration++) {
            const a = active[Math.floor(rng() * active.length)]; let b = active[Math.floor(rng() * active.length)];
            if (a === b) b = active[(active.indexOf(a) + 1) % active.length];
            const candidate = [...current], from = candidate.indexOf(a), to = candidate.indexOf(b);
            if (iteration % 2) [candidate[from], candidate[to]] = [candidate[to], candidate[from]];
            else { candidate.splice(from, 1); candidate.splice(to, 0, a); }
            const groups = evaluate(candidate, `direct-${restart}`);
            const fraction = proposals <= 1 ? 1 : iteration / (proposals - 1);
            const temperature = Math.max(0.1, Math.max(1, bytes.length * 0.001) * (1 - fraction) ** 3);
            if (groups <= currentCount || rng() < Math.exp((currentCount - groups) / temperature)) { current = candidate; currentCount = groups; }
        }
    }
    // Finish with exact full-input evaluations of adjacent active-symbol swaps.
    for (let sweep = 0; sweep < 3; sweep++) {
        let changed = false;
        const positions = bestOrder.map((byte, i) => frequency[byte] ? i : -1).filter(i => i >= 0);
        for (let i = 1; i < positions.length; i++) {
            const candidate = [...bestOrder], a = positions[i - 1], b = positions[i];
            [candidate[a], candidate[b]] = [candidate[b], candidate[a]];
            const previous = bestCount; evaluate(candidate, 'adjacent'); if (bestCount < previous) changed = true;
        }
        if (!changed) break;
    }
    return { order: bestOrder, groups: bestCount, baselineGroups: countGroups(bytes, rankOf(natural)), activeSymbols: active.length,
        seed, proposals, restarts, evaluations, searchMs: performance.now() - start, improvements,
        seedCandidates: candidates.map(({ groups, proxyScore }) => ({ groups, proxyScore })) };
}
