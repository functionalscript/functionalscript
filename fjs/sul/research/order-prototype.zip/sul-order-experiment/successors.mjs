// Additional grouping-only candidates; the original order-search run is retained.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { createHash } from 'node:crypto';
import { fixtures } from '../sul-ordered-experiment/benchmark.mjs';
import { naturalOrder, rankOf, measureGroups } from './order.mjs';

function statistics(bytes) {
    const frequency = new Uint32Array(256), transitions = new Uint32Array(65536);
    for (let i = 0; i < bytes.length; i++) {
        frequency[bytes[i]]++;
        if (i) transitions[bytes[i - 1] * 256 + bytes[i]]++;
    }
    const active = naturalOrder().filter(x => frequency[x]).sort((a, b) => frequency[b] - frequency[a] || a - b);
    return { frequency, transitions, active, absent: naturalOrder().filter(x => !frequency[x]) };
}

function chain(stats, leastStart = false) {
    const { frequency, transitions, active, absent } = stats;
    const remaining = new Set(active), highToLow = [];
    while (remaining.size) {
        const last = highToLow.at(-1);
        const next = [...remaining].sort((a, b) => (last === undefined ? 0 : transitions[last * 256 + b] - transitions[last * 256 + a]) || (last === undefined && leastStart ? frequency[a] - frequency[b] : frequency[b] - frequency[a]) || a - b)[0];
        highToLow.push(next); remaining.delete(next);
    }
    return { order: highToLow.reverse().concat(absent) };
}

function dag(stats, mode) {
    const { frequency, transitions, absent } = stats, candidates = [];
    const active = mode === 'leastFrequencyFirstDag' ? [...stats.active].sort((a, b) => frequency[a] - frequency[b] || a - b) : stats.active;
    if (mode === 'frequencyFirstDag' || mode === 'leastFrequencyFirstDag') {
        // For a fixed source a, sorting counts is equivalent to sorting P(b | a).
        for (const a of active) {
            const successors = active.filter(b => b !== a && transitions[a * 256 + b]).sort((b, c) => transitions[a * 256 + c] - transitions[a * 256 + b] || frequency[c] - frequency[b] || b - c);
            for (const b of successors) candidates.push([a, b, transitions[a * 256 + b]]);
        }
    } else {
        // Competing orientations differ by C(a,b)-C(b,a), not just C(a,b).
        for (const a of active) for (const b of active) {
            const margin = transitions[a * 256 + b] - transitions[b * 256 + a];
            if (margin > 0) candidates.push([a, b, margin]);
        }
        candidates.sort((a, b) => b[2] - a[2] || frequency[b[0]] - frequency[a[0]] || a[0] - b[0] || a[1] - b[1]);
    }
    const reach = Array(256).fill(0n), outgoing = Array.from({ length: 256 }, () => []), indegree = new Uint16Array(256);
    const accepted = []; let rejectedCycles = 0;
    for (const [a, b, weight] of candidates) {
        const abit = 1n << BigInt(a), bbit = 1n << BigInt(b);
        if (reach[b] & abit) { rejectedCycles++; continue; }
        const addition = reach[b] | bbit;
        for (const p of active) if (p === a || (reach[p] & abit)) reach[p] |= addition;
        outgoing[a].push(b); indegree[b]++; accepted.push([a, b, weight]);
    }
    // Edges point from higher rank to lower rank. Frequency resolves unrelated nodes.
    const pending = new Set(active), highToLow = [];
    while (pending.size) {
        const a = active.find(x => pending.has(x) && indegree[x] === 0);
        assert.notEqual(a, undefined, 'Cycle remained in the graph');
        highToLow.push(a); pending.delete(a);
        for (const b of outgoing[a]) indegree[b]--;
    }
    const order = highToLow.reverse().concat(absent), rank = rankOf(order);
    for (const [a, b] of accepted) assert(rank[a] > rank[b]);
    return { order, candidateEdges: candidates.length, acceptedEdges: accepted.length, rejectedCycles };
}

function descendingWeight(stats, order) {
    const rank = rankOf(order); let count = 0;
    for (const a of stats.active) for (const b of stats.active) if (rank[a] > rank[b]) count += stats.transitions[a * 256 + b];
    return count;
}

// A genuine directed cycle must be broken; a pure descending chain must be kept.
const cycle = dag(statistics(Uint8Array.of(0, 1, 2, 0, 1, 2, 0)), 'frequencyFirstDag');
assert.equal(cycle.acceptedEdges, 2); assert.equal(cycle.rejectedCycles, 1);
assert.deepEqual(cycle.order.slice(0, 3), [2, 1, 0]);
assert.deepEqual(chain(statistics(Uint8Array.of(0, 1, 2))).order.slice(0, 3), [2, 1, 0]);
assert.deepEqual(chain(statistics(new Uint8Array())).order, naturalOrder());

const previous = JSON.parse(fs.readFileSync(new URL('./results/results.json', import.meta.url)));
const report = { version: 1, scope: 'Grouping-only evaluation of five deterministic transition-graph candidates; no arithmetic coding or complete compression rerun.',
    orderDirection: 'ascending rank: original byte values, not substituted output bytes',
    methods: { successorChain: 'Start at the most frequent byte; choose the most frequent still-unvisited successor, breaking ties by frequency then byte. Reverse traversal to obtain ascending ranks.',
        successorChainLeastStart: 'As successorChain, but begin with the least frequent observed byte. Only the first choice changes.',
        frequencyFirstDag: 'Process sources by frequency, successors by conditional probability. Accept each edge unless it closes a cycle; topologically sort with frequency tie-breaking, then reverse.',
        leastFrequencyFirstDag: 'As frequencyFirstDag, but process least frequent sources first and prefer the least frequent available source during topological sorting.',
        marginDag: 'Orient each unequal pair toward the larger transition count, process descending net margins, reject cycles, topologically sort with frequency tie-breaking, then reverse.' }, fixtures: [] };
for (const [name, bytes] of fixtures) {
    const old = previous.fixtures.find(x => x.name === name);
    assert(old, 'Run the complete original benchmark first');
    assert.equal(createHash('sha256').update(bytes).digest('hex'), old.sha256);
    const stats = statistics(bytes), row = { name, inputBytes: bytes.length, sha256: old.sha256, naturalGroups: old.originalGroups.groups,
        previousBestSeedGroups: Math.min(...old.search.seedCandidates.map(x => x.groups)), previousSearchedGroups: old.optimizedGroups.groups, candidates: {} };
    for (const method of ['successorChain', 'successorChainLeastStart', 'frequencyFirstDag', 'leastFrequencyFirstDag', 'marginDag']) {
        const start = performance.now(), result = method.startsWith('successorChain') ? chain(stats, method === 'successorChainLeastStart') : dag(stats, method);
        row.candidates[method] = { ...result, ...measureGroups(bytes, result.order), descendingTransitionCount: descendingWeight(stats, result.order), milliseconds: performance.now() - start };
    }
    report.fixtures.push(row);
    console.log(JSON.stringify({ name, natural: row.naturalGroups, previousSeed: row.previousBestSeedGroups, searched: row.previousSearchedGroups,
        ...Object.fromEntries(Object.entries(row.candidates).map(([k, v]) => [k, v.groups])) }));
}
fs.writeFileSync(new URL('./results/successors.json', import.meta.url), JSON.stringify(report, null, 2) + '\n');
console.log('All fixture hashes, full permutations, accepted-edge orientations, cycle and chain checks passed.');
