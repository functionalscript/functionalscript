# Byte alphabet ordering experiment

This isolated Node.js research prototype optimizes the comparison order of the
256 byte values at level zero. It is not a supported FunctionalScript codec.

Run from the archive root with Node.js 24.19.0; no npm installation is needed:

```sh
node --test sul-order-experiment/test.mjs
node sul-order-experiment/benchmark.mjs
node sul-order-experiment/generalization.mjs
node sul-order-experiment/successors.mjs
node sul-order-experiment/cli.mjs order INPUT
node sul-order-experiment/cli.mjs encode INPUT OUTPUT.sulo
node sul-order-experiment/cli.mjs decode OUTPUT.sulo RESTORED
```

For a shorter reproduction, pass a fixture name to the benchmark, for example
`node sul-order-experiment/benchmark.mjs source_code`. This overwrites the report
with that subset; run the full benchmark before generalization.mjs.

All orders are arrays of original byte values in ascending comparison rank.
The rank controls only the first word generation's comparison and Patricia keys.
Original byte identities remain the payload; higher levels retain their existing
ordering and the adaptive arithmetic coder is unchanged. The explicit SULO
recipes decode without any order table or additional shared dictionary.

The search optimizes the actual full-input number of level-one groups, including
one final partial word if needed. It uses transition-based initial orders,
bounded direct simulated annealing, and adjacent-swap refinement. It is a
heuristic, not a global minimum over 256! permutations. The original order is a
candidate and is retained on a tie unless a strict improvement was found earlier.

Results include all ten fitted orders, grouping statistics, full compressed sizes,
padding, selected recursive dictionary levels, and candidate costs. The included
prior compressed byte controls are golden files checked byte for byte. New
compressed outputs are reproducible and are omitted from the archive. Timing
values are one-shot observations and are not expected to reproduce exactly.

The vendored FunctionalScript snapshot is pinned to
`d16a9ebf39b30a42e1b795bc329774d867196841`; its MIT license is included. Existing
prototype source and reports are retained to make fixture generation and controls
self-contained. The shared byte builder includes the new optional byteOrder
parameter, whose identity order is verified against the preceding experiment.

The successor-graph script adds five grouping-only candidate constructions, including
most-frequent and least-frequent starting choices. It reads the full benchmark
results but writes its own successors.json; it leaves compression results intact.
