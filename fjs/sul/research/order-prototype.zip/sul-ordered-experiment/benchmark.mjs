import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { gzipSync, gunzipSync, brotliCompressSync, brotliDecompressSync, zstdCompressSync, zstdDecompressSync, constants } from 'node:zlib';
import { fixtures as originalFixtures } from '../sul-compression-research/benchmark.mjs';
import { bytesToBits, buildGraph } from '../sul-compression-research/sul-graph.mjs';
import { encodeGraph, decodeDocument, arithmeticDocument, rawDocument } from '../sul-compression-research/codec.mjs';
import { wordTree, binaryTree } from './levels.mjs';
import { encodeOrdered, decodeOrdered } from './ordered.mjs';

const directory = new URL('./results/', import.meta.url); fs.mkdirSync(directory, { recursive: true });
const prior = JSON.parse(fs.readFileSync(new URL('../sul-compression-research/results/results.json', import.meta.url)));
const sentences = Array.from({ length: 16 }, (_, i) => `The immutable document from sensor ${i} shares a repeated sentence with the next revision.\n`);
const repeatedSentences = Buffer.from(Array.from({ length: 768 }, (_, i) => sentences[(i * 7 + (i >> 3)) % sentences.length]).join(''));
const uniqueSentences = Buffer.from(Array.from({ length: 768 }, (_, i) => `The immutable document from sensor ${i} shares a repeated phrase with the next revision.\n`).join(''));
export const fixtures = [...originalFixtures,
    ['repeated_sentences', repeatedSentences, '768 sentences drawn from 16 distinct sentences in deterministic mixed order; common phrases across sentence definitions.'],
    ['unique_sentences', uniqueSentences, '768 unique sentences with changing sensor numbers and common phrases; no identical full sentence.'],
];
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
const report = { version: 2, node: process.version, sulCommit: prior.sulCommit, order: 'first occurrence', hierarchies: ['native SUL word generations', 'expanded Patricia subtree heights'], fixtures: [] };

for (const [name, bytes, description] of fixtures) {
    const start = performance.now(), bits = bytesToBits(bytes), sha256 = createHash('sha256').update(bytes).digest('hex');
    const beforeTree = performance.now(), { root, stats: wordLevels, paddedBits, captured } = wordTree(bits);
    const treeMs = performance.now() - beforeTree;
    const row = { name, description, inputBytes: bytes.length, sha256, treeMs, wordLevels, paddedBits };
    const binaryRoot = binaryTree(captured);
    row.binaryHeight = binaryRoot.level;
    for (const [family, tree] of [['word', root], ['binary', binaryRoot]]) for (const recursive of [false, true]) {
        const before = performance.now(), result = encodeOrdered(tree, bits.length, { recursive });
        const encodeMs = performance.now() - before;
        const decodeStart = performance.now(); assert.equal(decodeOrdered(result.encoded), bits);
        const label = (family === 'word' ? '' : 'binary') + (family === 'word' ? (recursive ? 'recursive' : 'flat') : (recursive ? 'Recursive' : 'Flat'));
        row[label] = { bytes: result.encoded.length, hierarchicalBytes: result.hierarchicalBytes, encodeMs, decodeMs: performance.now() - decodeStart, states: result.states, layers: result.layers, literalBits: result.literalBits, literalMode: result.literalMode, container: result.container, trials: result.trials };
        fs.writeFileSync(new URL(`${name}-${label}.sulo`, directory), result.encoded);
    }
    const previous = prior.fixtures.find(f => f.name === name);
    if (previous) {
        assert.equal(previous.sha256, sha256);
        row.previousGrammarBytes = previous.bestGrammarBytes;
        row.previousHybridBytes = previous.hybridBytes;
        row.arithmeticOnlyBytes = previous.arithmeticOnlyBytes;
        row.gzip9Bytes = previous.gzip9Bytes; row.brotli11Bytes = previous.brotli11Bytes; row.zstd19Bytes = previous.zstd19Bytes;
    } else {
        const plain = arithmeticDocument(bits); assert.equal(decodeDocument(plain), bits);
        row.arithmeticOnlyBytes = plain.length;
        let bestGrammar = Infinity, bestHybrid = Math.min(plain.length, rawDocument(bits).length);
        for (const expanded of [false, true]) {
            const { root: graph } = buildGraph(captured, expanded);
            for (const minimumBits of [16, 32, 64, 128, 256]) for (const arithmetic of [false, true]) {
                const { encoded } = encodeGraph(graph, bits.length, { minimumBits, arithmetic });
                assert.equal(decodeDocument(encoded), bits);
                if (arithmetic) bestGrammar = Math.min(bestGrammar, encoded.length);
                bestHybrid = Math.min(bestHybrid, encoded.length);
            }
        }
        row.previousGrammarBytes = bestGrammar; row.previousHybridBytes = bestHybrid;
        for (const [label, compress, decompress] of [
            ['gzip9', b => gzipSync(b, { level: 9 }), gunzipSync],
            ['brotli11', b => brotliCompressSync(b, { params: { [constants.BROTLI_PARAM_QUALITY]: 11 } }), brotliDecompressSync],
            ['zstd19', b => zstdCompressSync(b, { params: { [constants.ZSTD_c_compressionLevel]: 19 } }), zstdDecompressSync],
        ]) {
            const encoded = compress(bytes); assert.deepEqual(decompress(encoded), bytes); row[label + 'Bytes'] = encoded.length;
        }
    }
    row.totalMs = performance.now() - start;
    report.fixtures.push(row);
    fs.writeFileSync(new URL('results.json', directory), JSON.stringify(report, null, 2) + '\n');
    console.log(JSON.stringify({name,input:bytes.length,old:row.previousHybridBytes,flat:row.flat.bytes,recursive:row.recursive.bytes,binaryFlat:row.binaryFlat.bytes,binaryRecursive:row.binaryRecursive.bytes,layers:row.recursive.layers.map(x=>x.level),literalBits:row.recursive.literalBits,seconds:+(row.totalMs/1000).toFixed(2)}));
}
const fields = ['name','inputBytes','previousGrammarBytes','previousHybridBytes','flatBytes','recursiveBytes','binaryFlatBytes','binaryRecursiveBytes','arithmeticOnlyBytes','gzip9Bytes','brotli11Bytes','zstd19Bytes'];
const rows = report.fixtures.map(r => ({...r,flatBytes:r.flat.bytes,recursiveBytes:r.recursive.bytes,binaryFlatBytes:r.binaryFlat.bytes,binaryRecursiveBytes:r.binaryRecursive.bytes}));
fs.writeFileSync(new URL('summary.csv', directory), fields.join(',')+'\n'+rows.map(r=>fields.map(k=>r[k]).join(',')).join('\n')+'\n');
console.log('All ordered outputs and newly computed baselines decoded exactly; prior fixture hashes matched.');
}
