import test from 'node:test';
import assert from 'node:assert/strict';
import { symbolTree } from './levels.mjs';
import { bytesToBits } from '../sul-compression-research/sul-graph.mjs';
import { flatten } from '../sul-ordered-experiment/levels.mjs';
import { encodeOrdered, decodeOrdered } from '../sul-ordered-experiment/ordered.mjs';

function verify(bits, width) {
    const tree = symbolTree(bits, width);
    assert.equal(flatten(tree.root), bits + '1' + '0'.repeat(tree.paddedBits - bits.length - 1));
    const visited = new Set();
    const visit = node => {
        if (visited.has(node.key)) return;
        visited.add(node.key);
        if (!node.children) { assert.equal(node.length, width); return; }
        assert.ok(node.children.length >= 2);
        for (let i = 1; i < node.children.length - 1; i++) assert.ok(node.children[i - 1].value > node.children[i].value);
        assert.ok(node.children.at(-1).value >= node.children.at(-2).value);
        for (const child of node.children) { assert.equal(child.level, node.level - 1); visit(child); }
    };
    visit(tree.root);
    for (const recursive of [false, true]) {
        const result = encodeOrdered(tree.root, bits.length, { recursive });
        assert.equal(decodeOrdered(result.encoded), bits);
        assert.ok(result.encoded.length <= 14 + Math.ceil(bits.length / 8));
    }
    return tree;
}

test('empty input and every single byte round-trip with complete byte leaves', () => {
    verify('', 8);
    for (let value = 0; value < 256; value++) verify(value.toString(2).padStart(8, '0'), 8);
});

test('matched raw-bit control accepts every bitstring of length zero to eight', () => {
    for (let length = 0; length <= 8; length++) for (let value = 0; value < 2 ** length; value++) {
        verify(length ? value.toString(2).padStart(length, '0') : '', 1);
    }
});

test('full alphabet, longest decreasing byte word, and boundary byte values', () => {
    const descending = Array.from({ length: 256 }, (_, i) => 255 - i);
    const bits = bytesToBits(Buffer.from([...descending, 0, ...descending.toReversed(), 255, 0, 128, 127]));
    const tree = verify(bits, 8);
    let first = tree.root;
    while (first.level > 1) first = first.children[0];
    assert.equal(first.children.length, 257);
    assert.deepEqual(first.children.map(node => parseInt(node.bits, 2)), [...descending, 0]);
});

test('repetition recursively compresses byte dictionaries and deterministic output', () => {
    const bits = bytesToBits(Buffer.from('The immutable document shares a repeated sentence.\n'.repeat(1024)));
    const a = symbolTree(bits, 8), b = symbolTree(bits, 8);
    assert.equal(a.root.value, b.root.value);
    const flat = encodeOrdered(a.root, bits.length, { recursive: false });
    const result = encodeOrdered(a.root, bits.length);
    assert.ok(result.layers.length > 1);
    assert.ok(result.encoded.length < flat.encoded.length);
    assert.deepEqual(result.encoded, encodeOrdered(b.root, bits.length).encoded);
    assert.equal(decodeOrdered(result.encoded), bits);
});

test('byte input refuses incomplete symbols, invalid digits, and unsupported widths', () => {
    assert.throws(() => symbolTree('101', 8));
    assert.throws(() => symbolTree('0000000x', 8));
    assert.throws(() => symbolTree('00', 2));
});
