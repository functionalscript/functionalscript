import fs from 'node:fs';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { fixtures } from '../sul-ordered-experiment/benchmark.mjs';
import { bytesToBits } from '../sul-compression-research/sul-graph.mjs';
import { encodeOrdered, decodeOrdered } from '../sul-ordered-experiment/ordered.mjs';
import { symbolTree } from './levels.mjs';

const directory = new URL('./results/', import.meta.url); fs.mkdirSync(directory, { recursive: true });
const prior = JSON.parse(fs.readFileSync(new URL('../sul-ordered-experiment/results/results.json', import.meta.url)));
const report = { version: 3, node: process.version, sulCommit: prior.sulCommit,
    order: 'first occurrence', variants: ['native bit SUL (previous run)', 'raw-bit SUL control', 'raw-byte SUL experiment'],
    arithmetic: 'unchanged adaptive binary coder and contexts from ordered experiment', fixtures: [] };
for (const [name, bytes, description] of fixtures) {
    const start = performance.now(), bits = bytesToBits(bytes), sha256 = createHash('sha256').update(bytes).digest('hex');
    const previous = prior.fixtures.find(row => row.name === name); assert.equal(previous.sha256, sha256);
    const row = { name, description, inputBytes: bytes.length, sha256,
        nativeBitFlatBytes: previous.flat.bytes, nativeBitRecursiveBytes: previous.recursive.bytes,
        previousHybridBytes: previous.previousHybridBytes, arithmeticOnlyBytes: previous.arithmeticOnlyBytes,
        gzip9Bytes: previous.gzip9Bytes, brotli11Bytes: previous.brotli11Bytes, zstd19Bytes: previous.zstd19Bytes };
    for (const [label, width] of [['rawBit', 1], ['rawByte', 8]]) {
        const beforeTree = performance.now(), tree = symbolTree(bits, width);
        row[label + 'Tree'] = { width, treeMs: performance.now() - beforeTree, paddedBits: tree.paddedBits, paddingSymbols: tree.paddingSymbols, levels: tree.stats };
        for (const recursive of [false, true]) {
            const before = performance.now(), result = encodeOrdered(tree.root, bits.length, { recursive });
            const encodeMs = performance.now() - before;
            const decodeStart = performance.now(); assert.equal(decodeOrdered(result.encoded), bits);
            const key = label + (recursive ? 'Recursive' : 'Flat');
            row[key] = { bytes: result.encoded.length, hierarchicalBytes: result.hierarchicalBytes, encodeMs,
                decodeMs: performance.now() - decodeStart, states: result.states, layers: result.layers,
                literalBits: result.literalBits, literalMode: result.literalMode, container: result.container, trials: result.trials };
            fs.writeFileSync(new URL(`${name}-${key}.sulo`, directory), result.encoded);
        }
    }
    row.totalMs = performance.now() - start; report.fixtures.push(row);
    fs.writeFileSync(new URL('results.json', directory), JSON.stringify(report, null, 2) + '\n');
    console.log(JSON.stringify({ name, input: bytes.length, nativeBit: row.nativeBitRecursiveBytes,
        rawBit: row.rawBitRecursive.bytes, rawByteFlat: row.rawByteFlat.bytes, rawByte: row.rawByteRecursive.bytes,
        byteLayers: row.rawByteRecursive.layers.map(layer => layer.level), seconds: +(row.totalMs / 1000).toFixed(2) }));
}
const fields = ['name','inputBytes','nativeBitFlatBytes','nativeBitRecursiveBytes','rawBitFlatBytes','rawBitRecursiveBytes','rawByteFlatBytes','rawByteRecursiveBytes','previousHybridBytes','arithmeticOnlyBytes','gzip9Bytes','brotli11Bytes','zstd19Bytes'];
const rows = report.fixtures.map(row => ({ ...row, rawBitFlatBytes: row.rawBitFlat.bytes, rawBitRecursiveBytes: row.rawBitRecursive.bytes, rawByteFlatBytes: row.rawByteFlat.bytes, rawByteRecursiveBytes: row.rawByteRecursive.bytes }));
fs.writeFileSync(new URL('summary.csv', directory), fields.join(',') + '\n' + rows.map(row => fields.map(key => row[key]).join(',')).join('\n') + '\n');
console.log('All 40 new encodings decoded exactly; all 10 reused fixture hashes matched.');
