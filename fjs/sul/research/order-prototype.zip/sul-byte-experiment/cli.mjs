import fs from 'node:fs';
import assert from 'node:assert/strict';
import { symbolTree } from './levels.mjs';
import { bytesToBits, bitsToBytes } from '../sul-compression-research/sul-graph.mjs';
import { encodeOrdered, decodeOrdered } from '../sul-ordered-experiment/ordered.mjs';

const [command, input, output, width = '8'] = process.argv.slice(2);
if (!input || !output || !['compress', 'decompress'].includes(command)) throw new Error('Usage: node cli.mjs compress|decompress INPUT OUTPUT [1|8]');
const source = fs.readFileSync(input);
if (command === 'compress') {
    const bits = bytesToBits(source), { root } = symbolTree(bits, Number(width));
    const result = encodeOrdered(root, bits.length);
    assert.equal(decodeOrdered(result.encoded), bits);
    fs.writeFileSync(output, result.encoded);
    console.log(JSON.stringify({ inputBytes: source.length, outputBytes: result.encoded.length, width: Number(width), layers: result.layers }));
} else fs.writeFileSync(output, bitsToBytes(decodeOrdered(source)));
