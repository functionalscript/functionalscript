# Byte-alphabet SUL compression experiment

Run from this directory with Node.js 24; no npm installation is required.
The pinned MIT-licensed SUL dependency snapshot is included under
sul-compression-research/vendor (commit d16a9ebf39b30a42e1b795bc329774d867196841).

This is a research prototype using SUL word/hash grouping from raw bit or byte
leaves. It bypasses the native three literal levels and changes the root IDs.
The ordered dictionary codec and adaptive binary arithmetic coder are unchanged.

```bash
node --test sul-compression-research/test.mjs sul-ordered-experiment/test.mjs sul-byte-experiment/test.mjs
node sul-byte-experiment/benchmark.mjs
node sul-byte-experiment/cli.mjs compress INPUT OUTPUT.sulo 8
node sul-byte-experiment/cli.mjs decompress OUTPUT.sulo RESTORED
```

Use width 1 for the matched raw-bit control. The benchmark checks fixture hashes,
reuses baseline sizes from the preceding experiment, decodes all 40 new encodings,
and writes their complete measurements and outputs to sul-byte-experiment/results.
Recorded results include all candidate costs. Encoded binaries are regenerated.
The original and ordered benchmarks can also be rerun from their own scripts.

The byte builder rejects partial bytes, unsupported widths, excessive depth, and
padding beyond max(65536, 4 * inputBits). This codec has no integrity checksum and
is an in-memory exploratory search rather than a supported archival format.

The full report, comparisons, source listing, and manifest are in PR 2047:
https://github.com/functionalscript/functionalscript/pull/2047
